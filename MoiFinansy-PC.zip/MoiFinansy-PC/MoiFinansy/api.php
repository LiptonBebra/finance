<?php
// ============================================================
// api.php — JSON API приложения (AJAX-запросы с фронтенда)
// ------------------------------------------------------------
// Правила безопасности:
//   • каждый запрос к данным требует активной сессии (uid);
//   • каждая мутация проверяет CSRF-токен;
//   • ВСЕ запросы к таблицам фильтруются по user_id текущего
//     пользователя — профили полностью изолированы;
//   • только предобработанные выражения (PDO prepared).
//
// Эндпоинты:
//   auth.check, auth.register, auth.login, auth.logout — аккаунт
//   onboarding.save                                    — мастер первого входа
//   tx.list, tx.add, tx.update, tx.delete              — операции
//   cat.list, cat.add, cat.update, cat.delete          — категории
//   savings.list, savings.add, savings.update,
//   savings.delete, savings.op                         — накопления
//   dashboard.get, stats.get                           — сводки
// ============================================================

require __DIR__ . '/db.php';

$action = (string)($_REQUEST['action'] ?? '');

// ============================================================
// 1. Аккаунт: регистрация, вход, выход
// ============================================================

/**
 * Завести профиль по имени и создать стартовые категории.
 * $pin — четыре цифры или пустая строка (защита необязательна:
 * это локальное приложение на компьютере пользователя).
 */
function register_user(PDO $pdo, string $name, string $pin): int
{
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare(
            'INSERT INTO users (name, pin_hash, onboarded) VALUES (?, ?, 0)'
        );
        $st->execute([
            $name,
            $pin !== '' ? password_hash($pin, PASSWORD_DEFAULT) : null,
        ]);
        $uid = (int)$pdo->lastInsertId();

        // Стартовые категории по умолчанию (свои — у каждого пользователя)
        $seed = $pdo->prepare(
            'INSERT INTO categories (user_id, type, name, icon, color) VALUES (?, ?, ?, ?, ?)'
        );
        $defaults = [
            ['income',  'Зарплата',          'fa-briefcase',        '#47A0DC'],
            ['income',  'Фриланс',           'fa-laptop-code',      '#6FC7B2'],
            ['income',  'Подарок',           'fa-gift',             '#E0709A'],
            ['income',  'Инвестиции',        'fa-chart-line',       '#5CC794'],
            ['income',  'Кэшбэк',            'fa-percent',          '#E3A95C'],
            ['income',  'Другое',            'fa-ellipsis',         '#9D8CE0'],
            ['expense', 'Продукты',          'fa-basket-shopping',  '#5CC794'],
            ['expense', 'Кафе и рестораны',  'fa-utensils',         '#E3A95C'],
            ['expense', 'Транспорт',         'fa-bus',              '#47A0DC'],
            ['expense', 'Жильё',             'fa-house',            '#8ECBDF'],
            ['expense', 'Здоровье',          'fa-heart-pulse',      '#E87A5C'],
            ['expense', 'Развлечения',       'fa-gamepad',          '#9D8CE0'],
            ['expense', 'Одежда',            'fa-shirt',            '#E0709A'],
            ['expense', 'Подписки',          'fa-tv',               '#6FC7B2'],
            ['expense', 'Образование',       'fa-graduation-cap',   '#8ECBDF'],
            ['expense', 'Другое',            'fa-ellipsis',         '#9AAFC0'],
        ];
        foreach ($defaults as [$type, $catName, $icon, $color]) {
            $seed->execute([$uid, $type, $catName, $icon, $color]);
        }

        $pdo->commit();
        return $uid;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

switch ($action) {

    // ---------- Шаг 1 входа: проверяем имя ----------
    // Возвращает, существует ли профиль и установлен ли у него PIN.
    case 'auth.check':
        csrf_check();

        $name = trim((string)($_POST['name'] ?? ''));
        if (mb_strlen($name) < 2 || mb_strlen($name) > 40) {
            json_reply(['ok' => false, 'error' => 'Имя: от 2 до 40 символов'], 422);
        }

        $user = find_user_by_name($pdo, $name);
        json_reply([
            'ok'     => true,
            'exists' => (bool)$user,
            'hasPin' => (bool)($user['pin_hash'] ?? false),
        ]);

    // ---------- Регистрация: имя + необязательный 4-значный PIN ----------
    case 'auth.register':
        csrf_check();

        $name = trim((string)($_POST['name'] ?? ''));
        $pin  = (string)($_POST['pin'] ?? '');

        if (mb_strlen($name) < 2 || mb_strlen($name) > 40) {
            json_reply(['ok' => false, 'error' => 'Имя: от 2 до 40 символов'], 422);
        }
        if ($pin !== '' && !preg_match('/^\d{4}$/', $pin)) {
            json_reply(['ok' => false, 'error' => 'PIN-код — ровно 4 цифры'], 422);
        }
        if (find_user_by_name($pdo, $name)) {
            json_reply(['ok' => false, 'error' => 'Профиль с таким именем уже есть — войдите'], 409);
        }

        $uid = register_user($pdo, $name, $pin);

        session_regenerate_id(true);           // защита от фиксации сессии
        $_SESSION['uid'] = $uid;
        json_reply(['ok' => true]);

    // ---------- Вход: имя (+ PIN, если он установлен) ----------
    case 'auth.login':
        csrf_check();

        $name = trim((string)($_POST['name'] ?? ''));
        $pin  = (string)($_POST['pin'] ?? '');

        $user = mb_strlen($name) >= 2 ? find_user_by_name($pdo, $name) : null;
        if (!$user) {
            json_reply(['ok' => false, 'error' => 'Профиль с таким именем не найден'], 401);
        }

        // Если профиль защищён PIN-кодом — проверяем его;
        // если PIN не задан, вход происходит просто по имени.
        if ($user['pin_hash'] !== null) {
            if (!preg_match('/^\d{4}$/', $pin) || !password_verify($pin, $user['pin_hash'])) {
                json_reply(['ok' => false, 'error' => 'Неверный PIN-код'], 401);
            }
        }

        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$user['id'];
        json_reply(['ok' => true]);

    // ---------- Выход (ссылка GET или форма POST) ----------
    case 'auth.logout':
        $_SESSION = [];
        session_destroy();
        header('Location: index.php?page=auth');
        exit;

    // ---------- Закрытие настольного приложения ----------
    // Кнопка «✕» внутри приложения отправляет запрос сюда: создаётся
    // файл-флаг data/stop, лаунчер MoiFinansy.exe замечает его и
    // корректно завершает работу (закрывает окно приложения и сервер).
    // В обычной вкладке браузера кнопка не показывается, так что
    // флаг случайно поставить нельзя.
    case 'app.shutdown':
        csrf_check();
        @touch(__DIR__ . '/data/stop');
        json_reply(['ok' => true]);
}

// ============================================================
// 2. Дальше — только для авторизованных
// ============================================================

$uid = current_user_id();
if (!$uid) {
    json_reply(['ok' => false, 'error' => 'Требуется вход'], 401);
}

// Проверка CSRF для всех мутаций (чтение — без него)
$mutating = in_array($action, [
    'tx.add', 'tx.update', 'tx.delete',
    'cat.add', 'cat.update', 'cat.delete',
    'savings.add', 'savings.update', 'savings.delete', 'savings.op',
    'onboarding.save',
], true);
if ($mutating) {
    csrf_check();
}

// ---------- Общие валидаторы ----------

/** Сумма: число больше нуля, максимум 2 знака */
function valid_amount(mixed $raw): ?float
{
    $v = str_replace([' ', ','], ['', '.'], trim((string)$raw));
    if ($v === '' || !is_numeric($v)) {
        return null;
    }
    $v = round((float)$v, 2);
    return ($v > 0 && $v <= 999999999999) ? $v : null;
}

/** Дата в формате YYYY-MM-DD (иначе null) */
function valid_date(string $raw): ?string
{
    $d = DateTime::createFromFormat('Y-m-d', $raw);
    return ($d && $d->format('Y-m-d') === $raw) ? $raw : null;
}

/** Сумма ≥ 0 (пустое поле = 0): для стартовых остатков мастера входа */
function valid_amount_or_zero(mixed $raw): ?float
{
    $v = str_replace([' ', ','], ['', '.'], trim((string)$raw));
    if ($v === '') return 0.0;
    if (!is_numeric($v)) return null;
    $v = round((float)$v, 2);
    return ($v >= 0 && $v <= 999999999999) ? $v : null;
}

/** Месяц в формате YYYY-MM (иначе null) */
function valid_month(string $raw): ?string
{
    $d = DateTime::createFromFormat('Y-m', $raw);
    return ($d && $d->format('Y-m') === $raw) ? $raw : null;
}

/** Ряд категории: принадлежит пользователю и имеет нужный тип */
function find_category(PDO $pdo, int $uid, int $catId, string $type): ?array
{
    $st = $pdo->prepare(
        'SELECT id, name, icon, color FROM categories
         WHERE id = ? AND user_id = ? AND type = ?'
    );
    $st->execute([$catId, $uid, $type]);
    return $st->fetch() ?: null;
}

/** Ряд накопления: принадлежит пользователю */
function find_saving(PDO $pdo, int $uid, int $sid): ?array
{
    $st = $pdo->prepare('SELECT * FROM savings WHERE id = ? AND user_id = ?');
    $st->execute([$sid, $uid]);
    return $st->fetch() ?: null;
}

/** Текущая сумма цели (внесено − снято) */
function goal_saved(PDO $pdo, int $sid): float
{
    $st = $pdo->prepare(
        "SELECT COALESCE(SUM(CASE WHEN op_type = 'in' THEN amount ELSE -amount END), 0)
         FROM savings_operations WHERE saving_id = ?"
    );
    $st->execute([$sid]);
    return round((float)$st->fetchColumn(), 2);
}

// ============================================================
// 2а. Мастер первого входа: стартовое финансовое положение
// ============================================================

/** Иконки/цвета для накоплений, заведённых мастером (по порядку) */
function onboarding_goal_style(int $i): array
{
    $icons  = ['fa-piggy-bank', 'fa-car', 'fa-house', 'fa-plane',
               'fa-graduation-cap', 'fa-gift', 'fa-landmark', 'fa-coins'];
    $colors = ['#E3A95C', '#47A0DC', '#5CC794', '#E0709A',
               '#9D8CE0', '#6FC7B2', '#E87A5C', '#95C77F'];
    return [$icons[$i % count($icons)], $colors[$i % count($colors)]];
}

switch ($action) {

    // ---------- Сохранение ответов мастера первого входа ----------
    // free  — сколько сейчас свободных средств;
    // goals — JSON-массив [{name, saved, target}]: существующие
    //         накопления и их суммы. Итог пишется так, чтобы баланс
    //         и «в накоплениях» сходились: initial_balance = free + Σsaved,
    //         в каждую цель добавляется операция «in» на сумму saved.
    case 'onboarding.save':
        // Мастер проходят один раз
        $st = $pdo->prepare('SELECT onboarded FROM users WHERE id = ?');
        $st->execute([$uid]);
        if ((int)$st->fetchColumn() === 1) {
            json_reply(['ok' => false, 'error' => 'Мастер уже пройден'], 409);
        }

        $free = valid_amount_or_zero($_POST['free'] ?? '');
        if ($free === null) {
            json_reply(['ok' => false, 'error' => 'Некорректная сумма свободных средств'], 422);
        }

        $rawGoals = json_decode((string)($_POST['goals'] ?? '[]'), true);
        if (!is_array($rawGoals)) {
            json_reply(['ok' => false, 'error' => 'Некорректный список накоплений'], 422);
        }

        // Валидация накоплений: имя обязательно, суммы ≥ 0
        $goals = [];
        foreach ($rawGoals as $g) {
            if (!is_array($g)) continue;
            $name  = trim((string)($g['name'] ?? ''));
            $saved = valid_amount_or_zero($g['saved'] ?? '');
            $target = valid_amount_or_zero($g['target'] ?? '');
            if ($name === '' || $saved === null || $target === null) continue;
            // Цель без суммы не имеет смысла — пропускаем пустые строки
            if ($saved <= 0 && $target <= 0) continue;
            $goals[] = [
                'name'   => mb_substr($name, 0, 40),
                'saved'  => $saved,
                // Целевая сумма не обязательна: по умолчанию = уже накоплено
                'target' => $target > 0 ? $target : max($saved, 0.01),
            ];
        }

        $pdo->beginTransaction();
        try {
            $totalSaved = array_sum(array_column($goals, 'saved'));

            // Стартовые средства = свободные деньги + всё, что уже в накоплениях
            $st = $pdo->prepare(
                'UPDATE users SET initial_balance = ?, onboarded = 1 WHERE id = ?'
            );
            $st->execute([round($free + $totalSaved, 2), $uid]);

            $addGoal = $pdo->prepare(
                'INSERT INTO savings (user_id, name, target_amount, icon, color)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $addOp = $pdo->prepare(
                'INSERT INTO savings_operations (user_id, saving_id, op_type, amount, comment)
                 VALUES (?, ?, ?, ?, ?)'
            );
            foreach ($goals as $i => $g) {
                [$icon, $color] = onboarding_goal_style($i);
                $addGoal->execute([$uid, $g['name'], $g['target'], $icon, $color]);
                $sid = (int)$pdo->lastInsertId();
                if ($g['saved'] > 0) {
                    $addOp->execute([$uid, $sid, 'in', $g['saved'], 'Начальный остаток']);
                }
            }

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        json_reply(['ok' => true]);
}

// ============================================================
// 3. Операции (доходы/расходы)
// ============================================================

switch ($action) {

    // ---------- Список операций за месяц + суммы по категориям ----------
    case 'tx.list':
        $type  = ($_POST['type'] ?? $_GET['type'] ?? '') === 'income' ? 'income' : 'expense';
        $month = valid_month((string)($_REQUEST['month'] ?? date('Y-m')));
        if ($month === null) {
            json_reply(['ok' => false, 'error' => 'Некорректный месяц'], 422);
        }

        // Границы месяца: сравнение по диапазону вместо substr() —
        // быстрее на любой глубине истории (задействует индекс по дате)
        $from = $month . '-01';
        $to   = (new DateTime($from))->modify('first day of next month')
                                     ->format('Y-m-d');
        $st = $pdo->prepare(
            'SELECT t.id, t.type, t.amount, t.comment, t.tx_date,
                    c.id AS cat_id, c.name AS cat_name, c.icon, c.color
             FROM transactions t
             JOIN categories c ON c.id = t.category_id
             WHERE t.user_id = ? AND t.type = ?
               AND t.tx_date >= ? AND t.tx_date < ?
             ORDER BY t.tx_date DESC, t.id DESC'
        );
        $st->execute([$uid, $type, $from, $to]);

        $txs       = [];
        $byCat     = [];
        $total     = 0.0;
        foreach ($st->fetchAll() as $r) {
            $r['amount'] = round((float)$r['amount'], 2);
            $txs[] = $r;
            $total += $r['amount'];
            $cid = (int)$r['cat_id'];
            if (!isset($byCat[$cid])) {
                $byCat[$cid] = [
                    'id' => $cid, 'name' => $r['cat_name'],
                    'icon' => $r['icon'], 'color' => $r['color'], 'sum' => 0.0,
                ];
            }
            $byCat[$cid]['sum'] += $r['amount'];
        }
        usort($byCat, fn($a, $b) => $b['sum'] <=> $a['sum']);
        foreach ($byCat as &$c) { $c['sum'] = round($c['sum'], 2); }
        unset($c);

        json_reply(['ok' => true, 'txs' => $txs, 'cats' => array_values($byCat),
                    'total' => round($total, 2)]);

    // ---------- Добавление операции ----------
    case 'tx.add':
        $type  = ($_POST['type'] ?? '') === 'income' ? 'income' : 'expense';
        $catId = (int)($_POST['category_id'] ?? 0);
        $amt   = valid_amount($_POST['amount'] ?? '');
        $date  = valid_date((string)($_POST['date'] ?? date('Y-m-d')));
        $cmt   = mb_substr(trim((string)($_POST['comment'] ?? '')), 0, 120);

        if ($amt === null)  json_reply(['ok' => false, 'error' => 'Введите сумму больше нуля'], 422);
        if ($date === null) json_reply(['ok' => false, 'error' => 'Некорректная дата'], 422);
        // Категория обязана принадлежать текущему пользователю и совпадать по типу
        if (!find_category($pdo, $uid, $catId, $type)) {
            json_reply(['ok' => false, 'error' => 'Категория не найдена'], 404);
        }

        $st = $pdo->prepare(
            'INSERT INTO transactions (user_id, category_id, type, amount, comment, tx_date)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $st->execute([$uid, $catId, $type, $amt, $cmt, $date]);
        json_reply(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);

    // ---------- Редактирование операции ----------
    case 'tx.update':
        $id = (int)($_POST['id'] ?? 0);
        $st = $pdo->prepare('SELECT * FROM transactions WHERE id = ? AND user_id = ?');
        $st->execute([$id, $uid]);
        $tx = $st->fetch();
        if (!$tx) json_reply(['ok' => false, 'error' => 'Операция не найдена'], 404);

        $type  = $tx['type'];                                   // тип операции не меняем
        $catId = (int)($_POST['category_id'] ?? $tx['category_id']);
        $amt   = isset($_POST['amount']) ? valid_amount($_POST['amount']) : (float)$tx['amount'];
        $date  = isset($_POST['date'])   ? valid_date((string)$_POST['date']) : $tx['tx_date'];
        $cmt   = isset($_POST['comment']) ? mb_substr(trim((string)$_POST['comment']), 0, 120) : $tx['comment'];

        if ($amt === null || $amt <= 0) {
            json_reply(['ok' => false, 'error' => 'Введите сумму больше нуля'], 422);
        }
        if ($date === null) json_reply(['ok' => false, 'error' => 'Некорректная дата'], 422);
        if (!find_category($pdo, $uid, $catId, $type)) {
            json_reply(['ok' => false, 'error' => 'Категория не найдена'], 404);
        }

        $st = $pdo->prepare(
            'UPDATE transactions
             SET category_id = ?, amount = ?, comment = ?, tx_date = ?
             WHERE id = ? AND user_id = ?'
        );
        $st->execute([$catId, $amt, $cmt, $date, $id, $uid]);
        json_reply(['ok' => true]);

    // ---------- Удаление операции ----------
    case 'tx.delete':
        $st = $pdo->prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?');
        $st->execute([(int)($_POST['id'] ?? 0), $uid]);
        json_reply(['ok' => $st->rowCount() > 0]);
}

// ============================================================
// 4. Категории
// ============================================================

switch ($action) {

    // ---------- Список категорий по типу ----------
    case 'cat.list':
        $type = ($_REQUEST['type'] ?? '') === 'income' ? 'income' : 'expense';
        $st   = $pdo->prepare(
            'SELECT id, name, icon, color FROM categories
             WHERE user_id = ? AND type = ? ORDER BY name'
        );
        $st->execute([$uid, $type]);
        json_reply(['ok' => true, 'cats' => $st->fetchAll()]);

    // ---------- Новая категория (видна только её создателю) ----------
    case 'cat.add':
        $type = ($_POST['type'] ?? '') === 'income' ? 'income' : 'expense';
        $name = trim((string)($_POST['name'] ?? ''));
        $icon = (string)($_POST['icon'] ?? 'fa-ellipsis');
        $color = (string)($_POST['color'] ?? '#47A0DC');

        if ($name === '' || mb_strlen($name) > 30) {
            json_reply(['ok' => false, 'error' => 'Название: 1–30 символов'], 422);
        }
        if (!preg_match('/^fa-[a-z0-9-]+$/i', $icon)) {
            json_reply(['ok' => false, 'error' => 'Некорректная иконка'], 422);
        }
        if (!preg_match('/^#[0-9a-f]{6}$/i', $color)) {
            json_reply(['ok' => false, 'error' => 'Некорректный цвет'], 422);
        }

        // Уникальность имени в рамках пользователя и типа
        $st = $pdo->prepare(
            'SELECT id FROM categories WHERE user_id = ? AND type = ? AND name = ?'
        );
        $st->execute([$uid, $type, $name]);
        if ($st->fetch()) {
            json_reply(['ok' => false, 'error' => 'Категория с таким названием уже есть'], 409);
        }

        $st = $pdo->prepare(
            'INSERT INTO categories (user_id, type, name, icon, color) VALUES (?, ?, ?, ?, ?)'
        );
        $st->execute([$uid, $type, $name, $icon, $color]);
        json_reply(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);

    // ---------- Редактирование категории ----------
    case 'cat.update':
        $id    = (int)($_POST['id'] ?? 0);
        $name  = trim((string)($_POST['name'] ?? ''));
        $icon  = (string)($_POST['icon'] ?? '');
        $color = (string)($_POST['color'] ?? '');

        $st = $pdo->prepare('SELECT * FROM categories WHERE id = ? AND user_id = ?');
        $st->execute([$id, $uid]);
        $cat = $st->fetch();
        if (!$cat) json_reply(['ok' => false, 'error' => 'Категория не найдена'], 404);

        if ($name === '' || mb_strlen($name) > 30) {
            json_reply(['ok' => false, 'error' => 'Название: 1–30 символов'], 422);
        }
        $icon  = $icon  !== '' ? $icon  : $cat['icon'];
        $color = $color !== '' ? $color : $cat['color'];
        if (!preg_match('/^fa-[a-z0-9-]+$/i', $icon) || !preg_match('/^#[0-9a-f]{6}$/i', $color)) {
            json_reply(['ok' => false, 'error' => 'Некорректные иконка/цвет'], 422);
        }

        $st = $pdo->prepare(
            'SELECT id FROM categories
             WHERE user_id = ? AND type = ? AND name = ? AND id != ?'
        );
        $st->execute([$uid, $cat['type'], $name, $id]);
        if ($st->fetch()) {
            json_reply(['ok' => false, 'error' => 'Категория с таким названием уже есть'], 409);
        }

        $st = $pdo->prepare(
            'UPDATE categories SET name = ?, icon = ?, color = ?
             WHERE id = ? AND user_id = ?'
        );
        $st->execute([$name, $icon, $color, $id, $uid]);
        json_reply(['ok' => true]);

    // ---------- Удаление категории ----------
    // По умолчанию категорию с операциями удалить нельзя (чтобы не
    // терять историю случайно). Если передан force=1 — вместе с
    // категорией удаляются все её операции (осознанный выбор).
    case 'cat.delete':
        $id    = (int)($_POST['id'] ?? 0);
        $force = (($_POST['force'] ?? '') === '1');

        // Категория обязана принадлежать текущему пользователю
        $st = $pdo->prepare('SELECT id, name FROM categories WHERE id = ? AND user_id = ?');
        $st->execute([$id, $uid]);
        $cat = $st->fetch();
        if (!$cat) json_reply(['ok' => false, 'error' => 'Категория не найдена'], 404);

        $st = $pdo->prepare(
            'SELECT COUNT(*) FROM transactions WHERE category_id = ? AND user_id = ?'
        );
        $st->execute([$id, $uid]);
        $used = (int)$st->fetchColumn();

        if ($used > 0 && !$force) {
            json_reply([
                'ok'    => false,
                'used'  => $used,
                'error' => 'В этой категории ' . plural_ops_count($used),
            ], 409);
        }

        $pdo->beginTransaction();
        try {
            if ($used > 0) {
                $st = $pdo->prepare(
                    'DELETE FROM transactions WHERE category_id = ? AND user_id = ?'
                );
                $st->execute([$id, $uid]);
            }
            $st = $pdo->prepare('DELETE FROM categories WHERE id = ? AND user_id = ?');
            $st->execute([$id, $uid]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        json_reply(['ok' => true]);
}

/** Согласование фразы «1 операция / 2 операции / 5 операций» */
function plural_ops_count(int $n): string
{
    $a = abs($n) % 100;
    $b = $a % 10;
    if ($a > 10 && $a < 20) return $n . ' операций — удаление также удалит их';
    if ($b > 1 && $b < 5)   return $n . ' операции — удаление также удалит их';
    if ($b === 1)           return $n . ' операция — удаление также удалит её';
    return $n . ' операций — удаление также удалит их';
}

// ============================================================
// 5. Накопления (цели)
// ============================================================

switch ($action) {

    // ---------- Список целей с суммами и последними операциями ----------
    case 'savings.list':
        $goals = [];
        $st = $pdo->prepare(
            'SELECT id, name, target_amount, icon, color, created_at
             FROM savings WHERE user_id = ? ORDER BY id'
        );
        $st->execute([$uid]);
        $opsSt = $pdo->prepare(
            'SELECT op_type, amount, comment, created_at
             FROM savings_operations WHERE saving_id = ?
             ORDER BY created_at DESC, id DESC'
        );
        foreach ($st->fetchAll() as $g) {
            $saved = goal_saved($pdo, (int)$g['id']);
            $opsSt->execute([(int)$g['id']]);
            $goals[] = [
                'id'     => (int)$g['id'],
                'name'   => $g['name'],
                'target' => round((float)$g['target_amount'], 2),
                'icon'   => $g['icon'],
                'color'  => $g['color'],
                'saved'  => $saved,
                'ops'    => $opsSt->fetchAll(),
            ];
        }
        json_reply(['ok' => true, 'goals' => $goals,
                    'balance' => user_balance($pdo, $uid)]);

    // ---------- Новая цель ----------
    case 'savings.add':
        $name   = trim((string)($_POST['name'] ?? ''));
        $target = valid_amount($_POST['target'] ?? '');
        $icon   = (string)($_POST['icon'] ?? 'fa-piggy-bank');
        $color  = (string)($_POST['color'] ?? '#E3A95C');

        if ($name === '' || mb_strlen($name) > 40) {
            json_reply(['ok' => false, 'error' => 'Название: 1–40 символов'], 422);
        }
        if ($target === null) {
            json_reply(['ok' => false, 'error' => 'Введите целевую сумму'], 422);
        }
        if (!preg_match('/^fa-[a-z0-9-]+$/i', $icon) || !preg_match('/^#[0-9a-f]{6}$/i', $color)) {
            json_reply(['ok' => false, 'error' => 'Некорректные иконка/цвет'], 422);
        }

        $st = $pdo->prepare(
            'INSERT INTO savings (user_id, name, target_amount, icon, color)
             VALUES (?, ?, ?, ?, ?)'
        );
        $st->execute([$uid, $name, $target, $icon, $color]);
        json_reply(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);

    // ---------- Редактирование цели ----------
    case 'savings.update':
        $id     = (int)($_POST['id'] ?? 0);
        $g      = find_saving($pdo, $uid, $id);
        if (!$g) json_reply(['ok' => false, 'error' => 'Цель не найдена'], 404);

        $name   = trim((string)($_POST['name'] ?? ''));
        $target = valid_amount($_POST['target'] ?? '');
        if ($name === '' || mb_strlen($name) > 40) {
            json_reply(['ok' => false, 'error' => 'Название: 1–40 символов'], 422);
        }
        if ($target === null) {
            json_reply(['ok' => false, 'error' => 'Введите целевую сумму'], 422);
        }

        $st = $pdo->prepare(
            'UPDATE savings SET name = ?, target_amount = ?
             WHERE id = ? AND user_id = ?'
        );
        $st->execute([$name, $target, $id, $uid]);
        json_reply(['ok' => true]);

    // ---------- Удаление цели (её операции удаляются каскадом) ----------
    case 'savings.delete':
        $st = $pdo->prepare('DELETE FROM savings WHERE id = ? AND user_id = ?');
        $st->execute([(int)($_POST['id'] ?? 0), $uid]);
        json_reply(['ok' => $st->rowCount() > 0]);

    // ---------- Пополнение / снятие ----------
    // Пополнение («in») уменьшает свободный баланс, снятие («out») —
    // возвращает деньги на баланс. Проверяем, что средств хватает.
    case 'savings.op':
        $id  = (int)($_POST['id'] ?? 0);
        $dir = ($_POST['dir'] ?? '') === 'out' ? 'out' : 'in';
        $amt = valid_amount($_POST['amount'] ?? '');
        $cmt = mb_substr(trim((string)($_POST['comment'] ?? '')), 0, 120);

        $g = find_saving($pdo, $uid, $id);
        if (!$g)          json_reply(['ok' => false, 'error' => 'Цель не найдена'], 404);
        if ($amt === null) json_reply(['ok' => false, 'error' => 'Введите сумму больше нуля'], 422);

        if ($dir === 'in') {
            // Нельзя отложить больше, чем есть свободными
            $free = user_balance($pdo, $uid);
            if ($amt > $free) {
                json_reply(['ok' => false,
                            'error' => 'На балансе не хватает средств: свободно ' .
                                       number_format($free, 0, ',', ' ') . ' ₽'], 409);
            }
        } else {
            // Нельзя снять больше, чем накоплено в цели
            $saved = goal_saved($pdo, $id);
            if ($amt > $saved) {
                json_reply(['ok' => false,
                            'error' => 'В цели накоплено только ' .
                                       number_format($saved, 0, ',', ' ') . ' ₽'], 409);
            }
        }

        $st = $pdo->prepare(
            'INSERT INTO savings_operations (user_id, saving_id, op_type, amount, comment)
             VALUES (?, ?, ?, ?, ?)'
        );
        $st->execute([$uid, $id, $dir, $amt, $cmt]);

        json_reply([
            'ok'      => true,
            'saved'   => goal_saved($pdo, $id),
            'balance' => user_balance($pdo, $uid),
        ]);
}

// ============================================================
// 6. Сводки: обзор и статистика
// ============================================================

/** Доходы/расходы за месяц + разбивка расходов по категориям */
function month_summary(PDO $pdo, int $uid, string $month): array
{
    // Диапазон месяца вместо substr() — работает по индексу
    $from = $month . '-01';
    $to   = (new DateTime($from))->modify('first day of next month')
                                 ->format('Y-m-d');

    $st = $pdo->prepare(
        "SELECT type, COALESCE(SUM(amount), 0) AS s
         FROM transactions
         WHERE user_id = ? AND tx_date >= ? AND tx_date < ?
         GROUP BY type"
    );
    $st->execute([$uid, $from, $to]);
    $sums = ['income' => 0.0, 'expense' => 0.0];
    foreach ($st->fetchAll() as $r) {
        $sums[$r['type']] = round((float)$r['s'], 2);
    }

    $st = $pdo->prepare(
        "SELECT c.name, c.color, c.icon, COALESCE(SUM(t.amount), 0) AS s
         FROM transactions t JOIN categories c ON c.id = t.category_id
         WHERE t.user_id = ? AND t.type = 'expense'
           AND t.tx_date >= ? AND t.tx_date < ?
         GROUP BY t.category_id ORDER BY s DESC"
    );
    $st->execute([$uid, $from, $to]);
    $byCat = array_map(function ($r) {
        return [
            'name'  => $r['name'],
            'color' => $r['color'],
            'icon'  => $r['icon'],
            'sum'   => round((float)$r['s'], 2),
        ];
    }, $st->fetchAll());

    return ['income' => $sums['income'], 'expense' => $sums['expense'], 'byCat' => $byCat];
}

switch ($action) {

    // ---------- Данные обзора (дашборд) ----------
    case 'dashboard.get':
        $month = valid_month((string)($_REQUEST['month'] ?? date('Y-m')));
        if ($month === null) json_reply(['ok' => false, 'error' => 'Некорректный месяц'], 422);

        $sum   = month_summary($pdo, $uid, $month);
        $saved = user_saved_total($pdo, $uid);

        // Динамика: доходы и расходы по месяцам.
        // Период: 6 месяцев (по умолчанию), 12 или всё время.
        $span = (string)($_REQUEST['span'] ?? '6');
        if (!in_array($span, ['6', '12', 'all'], true)) $span = '6';

        $dt = new DateTime($month . '-01');
        if ($span === 'all') {
            // Начало — от первой операции пользователя (но не глубже 600 мес.)
            $st = $pdo->prepare(
                "SELECT MIN(substr(tx_date, 1, 7)) FROM transactions WHERE user_id = ?"
            );
            $st->execute([$uid]);
            $min = $st->fetchColumn();
            if ($min) {
                $start = new DateTime($min . '-01');
                $limit = (clone $dt)->modify('-600 months');
                if ($start < $limit) $start = $limit;
            } else {
                $start = clone $dt;
            }
        } else {
            $start = (clone $dt)->modify('-' . ((int)$span - 1) . ' months');
        }

        // Месяцы от $start до выбранного месяца включительно
        $labels = [];
        $cur = clone $start;
        while ($cur <= $dt) {
            $k = $cur->format('Y-m');
            // Для длинных периодов подпись месяца дополняем годом: «янв ’25»
            $title      = ru_month_short($cur) . ($span !== '6' ? ' ’' . $cur->format('y') : '');
            $labels[$k] = ['key' => $k, 'title' => $title];
            $cur->modify('+1 month');
        }
        // Один проход по диапазону дат вместо перечисления месяцев:
        // скорость не зависит от глубины истории («Всё» — хоть десятилетия)
        $st = $pdo->prepare(
            "SELECT substr(tx_date, 1, 7) AS m, type, COALESCE(SUM(amount), 0) AS s
             FROM transactions
             WHERE user_id = ? AND tx_date >= ? AND tx_date < ?
             GROUP BY m, type"
        );
        $st->execute([$uid,
                      $start->format('Y-m-d'),
                      (clone $dt)->modify('first day of next month')->format('Y-m-d')]);
        $agg = [];
        foreach ($st->fetchAll() as $r) {
            $agg[$r['m']][$r['type']] = (float)$r['s'];
        }
        $incSer = [];
        $expSer = [];
        foreach ($labels as $k => $l) {
            $incSer[] = round($agg[$k]['income'] ?? 0, 2);
            $expSer[] = round($agg[$k]['expense'] ?? 0, 2);
        }

        json_reply([
            'ok'         => true,
            'balance'    => user_balance($pdo, $uid),
            'savedTotal' => $saved,
            'income'     => $sum['income'],
            'expense'    => $sum['expense'],
            'byCat'      => $sum['byCat'],
            'months'     => array_values(array_map(fn($l) => $l['title'], $labels)),
            'seriesInc'  => $incSer,
            'seriesExp'  => $expSer,
        ]);

    // ---------- Статистика за период ----------
    case 'stats.get':
        $from = valid_date((string)($_REQUEST['from'] ?? ''));
        $to   = valid_date((string)($_REQUEST['to'] ?? ''));

        // Если диапазон не передан или некорректен — текущий месяц
        if ($from === null || $to === null || $from > $to) {
            $from = date('Y-m-01');
            $to   = date('Y-m-t');
        }

        // Итоги периода
        $st = $pdo->prepare(
            "SELECT type, COALESCE(SUM(amount), 0) AS s
             FROM transactions WHERE user_id = ? AND tx_date BETWEEN ? AND ?
             GROUP BY type"
        );
        $st->execute([$uid, $from, $to]);
        $income = 0.0;
        $expense = 0.0;
        foreach ($st->fetchAll() as $r) {
            if ($r['type'] === 'income') $income = (float)$r['s']; else $expense = (float)$r['s'];
        }

        // Топ категорий расходов
        $st = $pdo->prepare(
            "SELECT c.name, c.color, c.icon, COALESCE(SUM(t.amount), 0) AS s,
                    COUNT(*) AS cnt
             FROM transactions t JOIN categories c ON c.id = t.category_id
             WHERE t.user_id = ? AND t.type = 'expense' AND t.tx_date BETWEEN ? AND ?
             GROUP BY t.category_id ORDER BY s DESC LIMIT 5"
        );
        $st->execute([$uid, $from, $to]);
        $top = array_map(function ($r) use ($expense) {
            return [
                'name'  => $r['name'],
                'color' => $r['color'],
                'icon'  => $r['icon'],
                'sum'   => round((float)$r['s'], 2),
                'cnt'   => (int)$r['cnt'],
                'pct'   => $expense > 0 ? round((float)$r['s'] * 100 / $expense, 1) : 0,
            ];
        }, $st->fetchAll());

        // Разбивка расходов по категориям (для круговой диаграммы)
        $st = $pdo->prepare(
            "SELECT c.name, c.color, COALESCE(SUM(t.amount), 0) AS s
             FROM transactions t JOIN categories c ON c.id = t.category_id
             WHERE t.user_id = ? AND t.type = 'expense' AND t.tx_date BETWEEN ? AND ?
             GROUP BY t.category_id ORDER BY s DESC"
        );
        $st->execute([$uid, $from, $to]);
        $pie = array_map(fn($r) => [
            'name'  => $r['name'],
            'color' => $r['color'],
            'sum'   => round((float)$r['s'], 2),
        ], $st->fetchAll());

        // Динамика трат за период (для линейного графика).
        // Шаг: day / week / month; 'auto' — как раньше: дни,
        // а для длинных периодов — недели.
        $gran = (string)($_REQUEST['gran'] ?? 'auto');
        if (!in_array($gran, ['auto', 'day', 'week', 'month'], true)) $gran = 'auto';

        // Траты по дням периода
        $st = $pdo->prepare(
            "SELECT tx_date, COALESCE(SUM(amount), 0) AS s
             FROM transactions
             WHERE user_id = ? AND type = 'expense' AND tx_date BETWEEN ? AND ?
             GROUP BY tx_date ORDER BY tx_date"
        );
        $st->execute([$uid, $from, $to]);
        $dayMap = [];
        foreach ($st->fetchAll() as $r) {
            $dayMap[$r['tx_date']] = (float)$r['s'];
        }
        $dLabels = [];
        $dSeries = [];
        $cur = new DateTime($from);
        $end = new DateTime($to);
        $days = (int)$cur->diff($end)->days + 1;

        // Фактический шаг (может отличаться от выбранного при защите от перегруза)
        $usedGran = $gran;
        if ($gran === 'auto') {
            $usedGran = ($days <= 62) ? 'day' : 'week';
        } elseif ($gran === 'day' && $days > 400) {
            // Более года по дням — точек слишком много, показываем недели
            $usedGran = 'week';
        }

        if ($usedGran === 'day') {
            while ($cur <= $end) {
                $k = $cur->format('Y-m-d');
                $dLabels[] = $cur->format('d.m');
                $dSeries[] = round($dayMap[$k] ?? 0, 2);
                $cur->modify('+1 day');
            }
        } elseif ($usedGran === 'week') {
            $weekSum = 0.0;
            $weekLbl = '';
            $i = 0;
            while ($cur <= $end) {
                $k = $cur->format('Y-m-d');
                $weekSum += $dayMap[$k] ?? 0;
                if ($i % 7 === 0) $weekLbl = $cur->format('d.m');
                if ($i % 7 === 6 || $cur == $end) {
                    $dLabels[] = $weekLbl;
                    $dSeries[] = round($weekSum, 2);
                    $weekSum = 0.0;
                }
                $cur->modify('+1 day');
                $i++;
            }
        } else {
            // По месяцам: подпись с годом при переходе («янв ’25»)
            $monthSums = [];
            foreach ($dayMap as $dk => $dv) {
                $mk = substr($dk, 0, 7);
                $monthSums[$mk] = ($monthSums[$mk] ?? 0) + $dv;
            }
            $mCur = (clone $cur)->modify('first day of this month');
            $mEnd = (clone $end)->modify('first day of this month');
            while ($mCur <= $mEnd) {
                $mk = $mCur->format('Y-m');
                $dLabels[] = ru_month_short($mCur) . ' ’' . $mCur->format('y');
                $dSeries[] = round($monthSums[$mk] ?? 0, 2);
                $mCur->modify('+1 month');
            }
        }

        json_reply([
            'ok'      => true,
            'from'    => $from,
            'to'      => $to,
            'income'  => round($income, 2),
            'expense' => round($expense, 2),
            'net'     => round($income - $expense, 2),
            'top'     => $top,
            'pie'     => $pie,
            'dLabels' => $dLabels,
            'dSeries' => $dSeries,
            'dGran'   => $usedGran,
        ]);
}

// Если действие не распознано
json_reply(['ok' => false, 'error' => 'Неизвестное действие'], 400);

/** Короткое название месяца: «янв», «фев»… */
function ru_month_short(DateTime $d): string
{
    $m = ['янв', 'фев', 'мар', 'апр', 'май', 'июн',
          'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
    return $m[(int)$d->format('n') - 1];
}
