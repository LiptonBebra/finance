/* ============================================================
   Мои финансы — клиентская логика (assets/js/app.js)
   ------------------------------------------------------------
   Структура:
     1. Утилиты и форматирование (+ плавный подсчёт сумм)
     2. API-помощник (fetch + CSRF)
     3. Тосты и модальные окна
     4. Тема (localStorage) и шапка (приветствие, дата)
     5. Справочники: иконки и цвета категорий
     6. Модалка категории (создание/редактирование/удаление)
     7. Модалка операции (создание/редактирование)
     8. Экран входа по имени (+ PIN) и мастер первого входа
     9. Страницы: обзор, доходы/расходы, накопления, статистика
   Взаимодействие с сервером — api.php (JSON, POST).
   Все данные изолированы по пользователю на стороне сервера.
   ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   *  1. Утилиты и форматирование
   * ============================================================ */

  const $  = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  // Форматирование денег: 12 345 (русская локаль, без копеек)
  const moneyFmt = new Intl.NumberFormat('ru-RU', {
    minimumFractionDigits: 0, maximumFractionDigits: 0,
  });
  const money = (v) => moneyFmt.format(Math.abs(v));
  const moneySigned = (v) => (v >= 0 ? '+' : '−') + money(v);

  /* Плавная анимация «подсчёта» суммы: число прокручивается от
   * предыдущего значения (хранится на элементе в data-num) к новому.
   * format — необязательный форматтер итоговой строки. */
  function countUp(el, value, format) {
    if (!el) return;
    const to   = Math.round((Number(value) || 0) * 100) / 100;
    const from = parseFloat(el.dataset.num || '0') || 0;
    el.dataset.num = String(to);

    const render = (v) => { el.textContent = format ? format(v) : money(v); };
    const reduce = window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (reduce || from === to) { render(to); return; }

    const duration = 750;
    const start    = performance.now();
    const ease     = (t) => 1 - Math.pow(1 - t, 3);   // easeOutCubic
    const tick     = (now) => {
      const p = Math.min(1, (now - start) / duration);
      render(from + (to - from) * ease(p));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  // Сокращённые названия месяцев
  const MONTHS = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь',
                  'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'];
  const MONTHS_SHORT = ['янв', 'фев', 'мар', 'апр', 'май', 'июн',
                        'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];

  // «Октябрь 2026» по ключу YYYY-MM
  function monthTitle(ym) {
    const [y, m] = ym.split('-').map(Number);
    return MONTHS[m - 1] + ' ' + y;
  }

  // Экранирование пользовательских строк в HTML
  function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  // Дата «сегодня» в формате YYYY-MM-DD
  function todayISO() {
    const d = new Date();
    return d.getFullYear() + '-' +
           String(d.getMonth() + 1).padStart(2, '0') + '-' +
           String(d.getDate()).padStart(2, '0');
  }

  // Заголовок дня для групп операций: «Сегодня, 30 октября»
  function dayTitleRu(iso) {
    const [y, m, d] = iso.split('-').map(Number);
    const gen = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
                 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
    const now = new Date();
    const date = new Date(y, m - 1, d);
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const diff = Math.round((today - date) / 86400000);
    if (diff === 0) return 'Сегодня, ' + d + ' ' + gen[m - 1];
    if (diff === 1) return 'Вчера, ' + d + ' ' + gen[m - 1];
    return d + ' ' + gen[m - 1];
  }

  // Дата-время операции накопления: «30.10, 14:05»,
  // а для прошлых лет — с годом: «30.10.24, 14:05»
  function dtShort(sql) {
    const [d, t] = (sql || '').split(' ');
    if (!d) return '';
    const [y, m, day] = d.split('-');
    const yy = (Number(y) === new Date().getFullYear()) ? '' : '.' + y.slice(2);
    return day + '.' + m + yy + (t ? ', ' + t.slice(0, 5) : '');
  }

  // Чтение CSS-переменной (для цветов Chart.js)
  function cssVar(name, fallback) {
    const v = getComputedStyle(document.documentElement)
      .getPropertyValue(name).trim();
    return v || fallback;
  }

  // '#47A0DC' + 0.85 -> 'rgba(71,160,220,.85)'
  function withAlpha(hex, a) {
    const h = (hex || '#000000').replace('#', '');
    if (h.length !== 6) return hex;
    const n = parseInt(h, 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
  }

  /* ============================================================
   *  2. API-помощник: POST + JSON + CSRF
   * ============================================================ */

  async function api(action, data) {
    const body = new URLSearchParams(data || {});
    body.set('action', action);
    const res = await fetch('api.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-CSRF-Token': window.APP.csrf,
      },
      body: body.toString(),
    });
    let json;
    try {
      json = await res.json();
    } catch (e) {
      throw new Error('Сервер вернул некорректный ответ');
    }
    if (!res.ok || json.ok === false) {
      throw new Error(json.error || 'Ошибка запроса (' + res.status + ')');
    }
    return json;
  }

  /* ============================================================
   *  3. Тосты
   * ============================================================ */

  function toast(message, isError) {
    const root = $('#toast-root');
    const el = document.createElement('div');
    el.className = 'toast' + (isError ? ' err' : '');
    el.innerHTML =
      '<i class="fa-solid ' + (isError ? 'fa-circle-exclamation' : 'fa-circle-check') +
      '" aria-hidden="true"></i><span>' + esc(message) + '</span>';
    root.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => {
      el.classList.remove('show');
      setTimeout(() => el.remove(), 250);
    }, 2600);
  }

  /* ============================================================
   *  4. Модальные окна
   * ============================================================ */

  // Открыть модалку: {title, body (HTML), onOpen(modalEl), footerless}
  function openModal({ title, body, onOpen }) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML =
      '<div class="modal" role="dialog" aria-modal="true">' +
      '  <div class="modal-head">' +
      '    <h3>' + esc(title) + '</h3>' +
      '    <button class="modal-close" type="button" aria-label="Закрыть">' +
      '      <i class="fa-solid fa-xmark" aria-hidden="true"></i>' +
      '    </button>' +
      '  </div>' +
      '  <div class="modal-body">' + body + '</div>' +
      '</div>';

    document.documentElement.classList.add('modal-open');
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('open'));

    const close = () => {
      overlay.classList.remove('open');
      setTimeout(() => {
        overlay.remove();
        // Блокировку скролла снимаем, только когда закрылась последняя
        // модалка: вложенные окна (категория внутри операции) не должны
        // возвращать прокрутку фона, пока операция ещё открыта
        if (!document.querySelector('.modal-overlay')) {
          document.documentElement.classList.remove('modal-open');
        }
      }, 220);
    };

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) close();          // клик по подложке
    });
    $('.modal-close', overlay).addEventListener('click', close);
    document.addEventListener('keydown', function onEsc(e) {
      if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onEsc); }
    });

    if (onOpen) onOpen($('.modal', overlay), close);
    return { close, el: overlay };
  }

  // Диалог подтверждения (удаления и т.п.)
  function confirmDialog(text, onYes) {
    openModal({
      title: 'Подтвердите',
      body:
        '<p class="confirm-text">' + esc(text) + '</p>' +
        '<div class="confirm-actions">' +
        '  <button class="btn" type="button" data-no>Отмена</button>' +
        '  <button class="btn btn-danger" type="button" data-yes>Удалить</button>' +
        '</div>',
      onOpen: (el, close) => {
        $('[data-no]', el).addEventListener('click', close);
        $('[data-yes]', el).addEventListener('click', () => { close(); onYes(); });
      },
    });
  }

  /* ============================================================
   *  5. Тема и шапка
   * ============================================================ */

  // Переключение тёмной/светлой темы с плавной перекраской
  function initTheme() {
    const btn = $('#theme-toggle');
    if (!btn) return;

    const applyIcon = () => {
      const light = document.documentElement.getAttribute('data-theme') === 'light';
      btn.innerHTML = '<i class="fa-solid ' + (light ? 'fa-moon' : 'fa-sun') +
                      '" aria-hidden="true"></i>';
    };
    applyIcon();

    btn.addEventListener('click', () => {
      const cur = document.documentElement.getAttribute('data-theme') === 'light'
        ? 'light' : 'dark';
      const next = cur === 'light' ? 'dark' : 'light';

      // Плавная перекраска всех элементов
      document.documentElement.classList.add('theme-anim');
      document.documentElement.setAttribute('data-theme', next);
      try { localStorage.setItem('fin-theme', next); } catch (e) { /* ignore */ }

      setTimeout(() => document.documentElement.classList.remove('theme-anim'), 280);
      applyIcon();

      // Перерисовать графики в новых цветах
      if (typeof window.__redrawPage === 'function') window.__redrawPage();
    });
  }

  // Выход из настольного приложения (стилизованный «✕»).
  // Кнопка видна только когда страница работает как приложение:
  // полноэкранный kiosk-режим или отдельное окно (--app).
  // В обычной вкладке браузера она скрыта.
  function initAppClose() {
    const btn = $('#app-close');
    if (!btn) return;

    const isAppMode =
      matchMedia('(display-mode: fullscreen)').matches ||
      matchMedia('(display-mode: standalone)').matches;
    if (!isAppMode) return;

    btn.classList.add('show');
    btn.addEventListener('click', () => {
      // Просим лаунчер остановить сервер (появится файл data/stop)
      api('app.shutdown').catch(() => {});
      // Окно приложения закрывается само; если браузер запретил —
      // лаунчер закроет его сам, а на этот случай показываем заглушку
      window.close();
      setTimeout(() => {
        document.body.innerHTML =
          '<div class="app-closed">' +
          '<i class="fa-solid fa-circle-check" aria-hidden="true"></i>' +
          '<h2>Приложение закрыто</h2>' +
          '<p>Это окно можно закрыть.</p></div>';
      }, 600);
    });
  }

  // Приветствие по времени суток + полная дата в шапке
  function initHeader() {
    const hello = $('#greet-hello');
    const dateBox = $('#topbar-date');
    if (!hello && !dateBox) return;

    const tick = () => {
      const now = new Date();
      const h = now.getHours();

      // Приветствие: утро / день / вечер / ночь
      if (hello) {
        let word = 'Доброй ночи';
        if (h >= 5 && h < 12)      word = 'Доброе утро';
        else if (h >= 12 && h < 17) word = 'Добрый день';
        else if (h >= 17 && h < 22) word = 'Добрый вечер';
        hello.textContent = word + ',';
      }

      // Полная дата: «четверг» + «30 октября 2026»
      if (dateBox) {
        const wd = ['воскресенье', 'понедельник', 'вторник', 'среда',
                    'четверг', 'пятница', 'суббота'][now.getDay()];
        const gen = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
                     'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
        $('.d-wd', dateBox).textContent = wd;
        $('.d-full', dateBox).textContent =
          now.getDate() + ' ' + gen[now.getMonth()] + ' ' + now.getFullYear() + ' г.';
      }
    };
    tick();
    setInterval(tick, 60000);   // обновлять раз в минуту
  }

  /* ============================================================
   *  6. Справочники иконок и цветов
   * ============================================================ */

  // Иконки Font Awesome для категорий и целей
  const ICONS = [
    'fa-basket-shopping', 'fa-utensils', 'fa-bus', 'fa-house', 'fa-heart-pulse',
    'fa-gamepad', 'fa-shirt', 'fa-tv', 'fa-graduation-cap', 'fa-briefcase',
    'fa-laptop-code', 'fa-gift', 'fa-chart-line', 'fa-percent', 'fa-piggy-bank',
    'fa-car', 'fa-plane', 'fa-music', 'fa-headphones',
    'fa-camera', 'fa-book', 'fa-dumbbell', 'fa-paw', 'fa-baby',
    'fa-file-invoice-dollar', 'fa-screwdriver-wrench', 'fa-plug', 'fa-broom', 'fa-landmark',
    'fa-crown', 'fa-leaf', 'fa-moon', 'fa-ellipsis', 'fa-wallet',
    'fa-coins', 'fa-mobile-screen', 'fa-dog', 'fa-spa', 'fa-paintbrush',
  ];

  // Предустановленные насыщенные цвета
  const COLORS = [
    '#47A0DC', '#8ECBDF', '#5CC794', '#95C77F',
    '#E3A95C', '#E87A5C', '#E0709A', '#9D8CE0',
    '#6FC7B2', '#D9B44A', '#9AAFC0', '#C792DF',
  ];

  /* ============================================================
   *  7. Модалка категории (создание / редактирование)
   * ============================================================ */

  // Открыть окно категории; onSaved вызывается после успешного сохранения
  function openCategoryModal({ type, cat = null, onSaved = null } = {}) {
    const isEdit = !!cat;
    let icon  = cat ? cat.icon  : (type === 'income' ? 'fa-coins' : 'fa-basket-shopping');
    let color = cat ? cat.color : COLORS[0];

    openModal({
      title: isEdit ? 'Категория' : 'Новая категория',
      body: `
        <form id="js-cat-form" novalidate autocomplete="off">
          <label class="field">
            <span class="field-label">Название</span>
            <input type="text" id="js-cat-name" maxlength="30"
                   placeholder="Например, ${type === 'income' ? 'Премия' : 'Хобби'}"
                   value="${esc(cat ? cat.name : '')}">
          </label>

          <span class="field-label">Иконка</span>
          <div class="icon-grid" id="js-cat-icons">
            ${ICONS.map((ic) => `
              <button class="icon-cell ${ic === icon ? 'active' : ''}" type="button"
                      data-icon="${ic}"><i class="fa-solid ${ic}"></i></button>
            `).join('')}
          </div>

          <span class="field-label" style="margin-top:14px">Цвет</span>
          <div class="swatches" id="js-cat-colors">
            ${COLORS.map((c) => `
              <button class="swatch ${c === color ? 'active' : ''}" type="button"
                      data-color="${c}" style="--c:${c}"
                      aria-label="Цвет ${c}"></button>
            `).join('')}
          </div>

          <div style="margin-top:18px;display:flex;gap:10px">
            ${isEdit ? '<button class="btn btn-danger-ghost" type="button" id="js-cat-del" '
              + 'title="Удалить категорию" aria-label="Удалить категорию">'
              + '<i class="fa-solid fa-trash-can" aria-hidden="true"></i></button>' : ''}
            <button class="btn" type="button" id="js-cat-cancel">Отмена</button>
            <button class="btn btn-primary" type="submit" style="flex:1">
              ${isEdit ? 'Сохранить' : 'Добавить'}
            </button>
          </div>
        </form>`,
      onOpen: (el, close) => {
        // Выбор иконки
        $('#js-cat-icons', el).addEventListener('click', (e) => {
          const b = e.target.closest('.icon-cell');
          if (!b) return;
          icon = b.dataset.icon;
          $$('.icon-cell', el).forEach((x) => x.classList.toggle('active', x === b));
        });
        // Выбор цвета
        $('#js-cat-colors', el).addEventListener('click', (e) => {
          const b = e.target.closest('.swatch');
          if (!b) return;
          color = b.dataset.color;
          $$('.swatch', el).forEach((x) => x.classList.toggle('active', x === b));
        });
        $('#js-cat-cancel', el).addEventListener('click', close);

        // Удаление категории (кнопка есть только при редактировании)
        const delBtn = $('#js-cat-del', el);
        if (delBtn) {
          delBtn.addEventListener('click', () => {
            close();
            deleteCategory(cat, onSaved);
          });
        }

        // Сохранение
        $('#js-cat-form', el).addEventListener('submit', async (e) => {
          e.preventDefault();
          const name = $('#js-cat-name', el).value.trim();
          if (!name) return toast('Введите название категории', true);

          try {
            let saved;
            if (isEdit) {
              await api('cat.update', { id: cat.id, name, icon, color });
              saved = { id: cat.id, name, icon, color };
            } else {
              const res = await api('cat.add', { type, name, icon, color });
              saved = { id: res.id, name, icon, color };
            }
            close();
            toast(isEdit ? 'Категория обновлена' : 'Категория добавлена');
            // Сброс кэша категорий: форма расхода/дохода, открытая сразу
            // после этого, обязана показать свежий список (с новой категорией)
            catCache[type] = null;
            if (onSaved) onSaved(saved);
          } catch (err) {
            toast(err.message, true);
          }
        });

        $('#js-cat-name', el).focus();
      },
    });
  }

  /* Удаление категории с бережной обработкой «занятой» категории:
   * если в ней есть операции, сервер сначала отказывает — тогда
   * предлагаем удалить категорию вместе со всеми её операциями. */
  async function deleteCategory(cat, onDone) {
    confirmDialog(
      'Удалить категорию «' + cat.name + '»?',
      async () => {
        try {
          await api('cat.delete', { id: cat.id });
          catCache.income = catCache.expense = null;
          toast('Категория удалена');
          if (onDone) onDone();
        } catch (err) {
          // В категории есть операции: спрашиваем про удаление вместе с ними
          confirmDialog(
            'Категория «' + cat.name + '»: ' + err.message + '. ' +
            'Удалить её вместе со всеми операциями? Восстановить их будет нельзя.',
            async () => {
              try {
                await api('cat.delete', { id: cat.id, force: 1 });
                catCache.income = catCache.expense = null;
                toast('Категория удалена вместе с операциями');
                if (onDone) onDone();
              } catch (err2) {
                toast(err2.message, true);
              }
            });
        }
      });
  }

  /* ============================================================
   *  8. Модалка операции (создание / редактирование)
   * ============================================================ */

  // Кэш категорий по типам (загружается лениво)
  const catCache = { income: null, expense: null };
  async function loadCats(type, force) {
    if (!catCache[type] || force) {
      const res = await api('cat.list', { type });
      catCache[type] = res.cats;
    }
    return catCache[type];
  }

  // Отрисовать выбор категорий в модалке операции
  function renderCatPicker(box, list) {
    box.innerHTML = list.map((c) => `
      <button class="cat-pick" type="button" data-id="${c.id}" style="--c:${esc(c.color)}">
        <i class="fa-solid ${esc(c.icon)}"></i>${esc(c.name)}
      </button>`).join('') +
      '<button class="cat-pick cat-pick-add" type="button" id="js-tx-cat-add">' +
      '<i class="fa-solid fa-plus"></i>Новая</button>';
  }

  // Открыть окно операции: {type, tx=null, onSaved, switchable}
  // switchable — разрешить переключение доход/расход (окно с «Обзора»)
  async function openTxModal({ type, tx = null, onSaved = null, switchable = false }) {
    const isEdit = !!tx;
    let catId = tx ? tx.cat_id : null;

    let cats;
    try {
      cats = await loadCats(type);
    } catch (err) {
      return toast(err.message, true);
    }

    openModal({
      title: (isEdit ? 'Изменить ' : 'Новый ') +
             (type === 'income' ? 'доход' : 'расход'),
      body: `
        <form id="js-tx-form" novalidate autocomplete="off">
          ${switchable && !isEdit ? `
          <div class="seg seg-type" id="js-tx-type" role="tablist" aria-label="Тип операции">
            <button class="seg-btn ${type === 'expense' ? 'active' : ''}" type="button" data-t="expense">Расход</button>
            <button class="seg-btn ${type === 'income' ? 'active' : ''}" type="button" data-t="income">Доход</button>
          </div>` : ''}
          <label class="field">
            <span class="field-label">Сумма</span>
            <span class="input-affix">
              <input type="text" id="js-tx-amount" inputmode="decimal"
                     placeholder="0" value="${isEdit ? tx.amount : ''}">
              <span class="affix">₽</span>
            </span>
          </label>

          <span class="field-label">Категория</span>
          <div class="cat-picker" id="js-tx-cats">
            ${cats.map((c) => `
              <button class="cat-pick ${tx && c.id === tx.cat_id ? 'active' : ''}"
                      type="button" data-id="${c.id}" style="--c:${esc(c.color)}">
                <i class="fa-solid ${esc(c.icon)}"></i>${esc(c.name)}
              </button>`).join('')}
            <button class="cat-pick cat-pick-add" type="button" id="js-tx-cat-add">
              <i class="fa-solid fa-plus"></i>Новая
            </button>
          </div>

          <label class="field" style="margin-top:14px">
            <span class="field-label">Дата</span>
            <input type="date" id="js-tx-date" value="${isEdit ? tx.tx_date : todayISO()}">
          </label>

          <label class="field">
            <span class="field-label">Комментарий
              <i class="char-count" id="js-tx-count">${isEdit ? tx.comment.length : 0}/120</i>
            </span>
            <textarea id="js-tx-comment" maxlength="120"
                      placeholder="Необязательно">${esc(tx ? tx.comment : '')}</textarea>
          </label>

          <div style="display:flex;gap:10px">
            <button class="btn" type="button" id="js-tx-cancel">Отмена</button>
            <button class="btn btn-primary" type="submit" style="flex:1">
              ${isEdit ? 'Сохранить' : 'Добавить'}
            </button>
          </div>
        </form>`,
      onOpen: (el, close) => {
        // Выбор категории / создание новой (делегирование — список
        // категорий может перерисовываться без потери обработчиков)
        $('#js-tx-cats', el).addEventListener('click', (e) => {
          if (e.target.closest('#js-tx-cat-add')) {
            openCategoryModal({
              type,
              // saved — только что сохранённая категория: сразу её выбираем
              onSaved: async (saved) => {
                let fresh;
                try {
                  fresh = await loadCats(type, true);
                } catch (err) {
                  // Даже если перезагрузка списка сорвалась — категория
                  // обязана появиться в пикере немедленно
                  fresh = [...(catCache[type] || []), saved];
                }
                if (!fresh.length && saved) fresh = [saved];
                renderCatPicker($('#js-tx-cats', el), fresh);
                catId = (saved && fresh.some((c) => c.id === saved.id))
                  ? saved.id
                  : fresh[fresh.length - 1].id;
                $$('#js-tx-cats .cat-pick', el).forEach((b) =>
                  b.classList.toggle('active', Number(b.dataset.id) === catId));
                const act = $('#js-tx-cats .cat-pick.active', el);
                if (act && act.scrollIntoView) {
                  act.scrollIntoView({ block: 'nearest', inline: 'nearest' });
                }
              },
            });
            return;
          }
          const b = e.target.closest('.cat-pick');
          if (!b) return;
          catId = Number(b.dataset.id);
          $$('.cat-pick', el).forEach((x) => x.classList.toggle('active', x === b));
        });

        // Смена типа операции (когда окно открыто с «Обзора»)
        if (switchable && !isEdit) {
          $('#js-tx-type', el).addEventListener('click', async (e) => {
            const b = e.target.closest('.seg-btn');
            if (!b || b.dataset.t === type) return;
            type = b.dataset.t;
            $$('#js-tx-type .seg-btn', el).forEach((x) => x.classList.toggle('active', x === b));
            $('.modal-head h3', el).textContent = 'Новый ' + (type === 'income' ? 'доход' : 'расход');
            catId = null;
            try {
              const fresh = await loadCats(type, true);
              renderCatPicker($('#js-tx-cats', el), fresh);
            } catch (err) {
              toast(err.message, true);
            }
          });
        }

        // Счётчик комментариев
        const ta = $('#js-tx-comment', el);
        ta.addEventListener('input', () => {
          $('#js-tx-count', el).textContent = ta.value.length + '/120';
        });

        $('#js-tx-cancel', el).addEventListener('click', close);

        // Сохранение операции
        $('#js-tx-form', el).addEventListener('submit', async (e) => {
          e.preventDefault();
          const amount = $('#js-tx-amount', el).value.replace(/\s/g, '').replace(',', '.');
          const date   = $('#js-tx-date', el).value;
          const comment = ta.value.trim();

          if (!catId) return toast('Выберите категорию', true);
          if (!(parseFloat(amount) > 0)) return toast('Введите сумму больше нуля', true);
          if (!date) return toast('Выберите дату', true);

          try {
            if (isEdit) {
              await api('tx.update', { id: tx.id, category_id: catId, amount, date, comment });
            } else {
              await api('tx.add', { type, category_id: catId, amount, date, comment });
            }
            close();
            toast(isEdit ? 'Операция обновлена' : 'Операция добавлена');
            if (onSaved) onSaved();
          } catch (err) {
            toast(err.message, true);
          }
        });

        $('#js-tx-amount', el).focus();
      },
    });
  }

  /* ============================================================
   *  9. Экран входа и регистрации (имя + необязательный PIN)
   * ============================================================ */

  function initAuthPage() {
    const formName  = $('#form-name');
    const stepLogin = $('#step-login');
    const stepReg   = $('#step-register');

    const errBoxes = {
      name:  $('#auth-error'),
      login: $('#login-error'),
      reg:   $('#reg-error'),
    };
    const showError = (box, msg) => {
      if (!box) return;
      box.textContent = msg;
      box.hidden = false;
    };
    const hideError = (box) => { if (box) box.hidden = true; };

    let profileName = '';   // имя, проверенное на первом шаге
    let loginPin    = '';   // ввод PIN при входе
    let regPin      = '';   // ввод PIN при регистрации

    // ---------- Переключение шагов ----------
    function showStep(step) {
      formName.hidden  = step !== 'name';
      stepLogin.hidden = step !== 'login';
      stepReg.hidden   = step !== 'register';
    }

    // ---------- Точки-индикаторы ввода PIN ----------
    function paintDots(dotsEl, pin) {
      $$('.pin-dot', dotsEl).forEach((d, i) =>
        d.classList.toggle('filled', i < pin.length));
    }

    // ---------- Экранная клавиатура PIN ----------
    function buildPad(root, onKey) {
      const layout = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'back', '0', ''];
      layout.forEach((k) => {
        if (k === '') return;                     // пустая ячейка сетки
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'pin-key' + (k === 'back' ? ' pin-key-back' : '');
        b.setAttribute('aria-label', k === 'back' ? 'Стереть цифру' : 'Цифра ' + k);
        b.innerHTML = k === 'back'
          ? '<i class="fa-solid fa-delete-left" aria-hidden="true"></i>'
          : '<span class="num">' + k + '</span>';
        b.addEventListener('click', () => onKey(k));
        root.appendChild(b);
      });
    }

    // Поддержка физической клавиатуры: цифры и Backspace (удобно на ПК)
    function bindKeyboard(getStep, onDigit, onBack) {
      document.addEventListener('keydown', (e) => {
        if (getStep() === 'name' || e.ctrlKey || e.metaKey || e.altKey) return;
        if (/^\d$/.test(e.key)) { onDigit(e.key); e.preventDefault(); }
        else if (e.key === 'Backspace') { onBack(); e.preventDefault(); }
      });
    }

    // ---------- Шаг 1: имя → куда идём дальше ----------
    formName.addEventListener('submit', async (e) => {
      e.preventDefault();
      hideError(errBoxes.name);

      const name = $('#auth-name').value.trim();
      if (name.length < 2) {
        return showError(errBoxes.name, 'Введите имя (минимум 2 символа)');
      }

      const btn = $('#btn-name-continue');
      btn.disabled = true;
      try {
        const res = await api('auth.check', { name });
        btn.disabled = false;
        profileName = name;
        $('#login-hello-name').textContent = name;
        $('#reg-hello-name').textContent   = name;

        if (res.exists && res.hasPin) {
          // Существующий защищённый профиль: вводим PIN
          loginPin = '';
          paintDots($('#pin-dots-login'), loginPin);
          showStep('login');
        } else if (res.exists) {
          // Существующий профиль без PIN: вход одним именем
          try {
            await api('auth.login', { name });
            location.href = 'index.php';
          } catch (err) {
            showError(errBoxes.name, err.message);
          }
        } else {
          // Новый профиль: предлагаем задать PIN (можно пропустить)
          regPin = '';
          paintDots($('#pin-dots-reg'), regPin);
          showStep('register');
        }
      } catch (err) {
        btn.disabled = false;
        showError(errBoxes.name, err.message);
      }
    });

    // ---------- Шаг 2а: вход по PIN (автоматически на 4-й цифре) ----------
    async function tryLogin() {
      try {
        await api('auth.login', { name: profileName, pin: loginPin });
        location.href = 'index.php';
      } catch (err) {
        showError(errBoxes.login, err.message);
        loginPin = '';
        paintDots($('#pin-dots-login'), loginPin);
      }
    }

    buildPad($('#pin-pad-login'), (k) => {
      hideError(errBoxes.login);
      if (k === 'back') {
        loginPin = loginPin.slice(0, -1);
      } else if (loginPin.length < 4) {
        loginPin += k;
      }
      paintDots($('#pin-dots-login'), loginPin);
      if (loginPin.length === 4) tryLogin();
    });

    bindKeyboard(
      () => formName.hidden ? 'pin' : 'name',
      (d) => {
        if (stepLogin.hidden) return;
        if (loginPin.length < 4) {
          loginPin += d;
          paintDots($('#pin-dots-login'), loginPin);
          if (loginPin.length === 4) tryLogin();
        }
      },
      () => {
        if (stepLogin.hidden) return;
        loginPin = loginPin.slice(0, -1);
        paintDots($('#pin-dots-login'), loginPin);
      }
    );

    $('#btn-back-login').addEventListener('click', () => {
      loginPin = '';
      hideError(errBoxes.login);
      showStep('name');
      $('#auth-name').focus();
    });

    // ---------- Шаг 2б: регистрация + предложение PIN ----------
    async function tryRegister(pin) {
      const btn = $('#btn-register');
      btn.disabled = true;
      try {
        await api('auth.register', { name: profileName, pin });
        location.href = 'index.php';       // дальше мастер первого входа
      } catch (err) {
        btn.disabled = false;
        showError(errBoxes.reg, err.message);
      }
    }

    buildPad($('#pin-pad-reg'), (k) => {
      hideError(errBoxes.reg);
      if (k === 'back') regPin = regPin.slice(0, -1);
      else if (regPin.length < 4) regPin += k;
      paintDots($('#pin-dots-reg'), regPin);
    });

    $('#btn-register').addEventListener('click', () => {
      if (regPin.length !== 0 && regPin.length !== 4) {
        return showError(errBoxes.reg, 'Введите 4 цифры или продолжите без PIN-кода');
      }
      tryRegister(regPin);
    });

    $('#btn-skip-pin').addEventListener('click', () => tryRegister(''));

    $('#btn-back-register').addEventListener('click', () => {
      regPin = '';
      hideError(errBoxes.reg);
      showStep('name');
      $('#auth-name').focus();
    });

    $('#auth-name').focus();
  }

  /* ============================================================
   *  9а. Мастер первого входа (onboarding)
   * ============================================================ */

  function initOnboarding() {
    const steps  = $$('.onb-step');
    const dots   = $$('.onb-dot');
    const errBox = $('#onb-error');
    let step     = 1;

    const showError = (msg) => { errBox.textContent = msg; errBox.hidden = false; };
    const hideError = () => { errBox.hidden = true; };

    // Читаемая сумма из поля: «12 345,67» → 12345.67 (null, если не число)
    const parseAmount = (v) => {
      const n = parseFloat(String(v).replace(/\s/g, '').replace(',', '.'));
      return isFinite(n) && n >= 0 ? Math.round(n * 100) / 100 : null;
    };

    // ---------- Строка накопления: имя + накоплено + цель ----------
    function goalRow() {
      const div = document.createElement('div');
      div.className = 'onb-goal-row';
      div.innerHTML =
        '<button class="btn-icon onb-goal-del" type="button" aria-label="Убрать накопление">' +
        '<i class="fa-solid fa-trash-can" aria-hidden="true"></i></button>' +
        '<div class="onb-goal-fields">' +
        '<input type="text" class="onb-g-name" maxlength="40" placeholder="Например, На машину" autocomplete="off">' +
        '<input type="text" class="onb-g-saved num" inputmode="decimal" placeholder="Накоплено, ₽" autocomplete="off">' +
        '<input type="text" class="onb-g-target num" inputmode="decimal" placeholder="Цель, ₽ (необязательно)" autocomplete="off">' +
        '</div>';
      $('.onb-goal-del', div).addEventListener('click', () => div.remove());
      return div;
    }

    const goalsBox = $('#onb-goals');
    goalsBox.appendChild(goalRow());               // сразу одна пустая строка

    $('#onb-add-goal').addEventListener('click', () => {
      const row = goalRow();
      goalsBox.appendChild(row);
      $('.onb-g-name', row).focus();
    });

    // Собираем накопления, отбрасывая пустые строки
    function collectGoals() {
      return $$('.onb-goal-row', goalsBox).map((row) => ({
        name:   $('.onb-g-name',   row).value.trim(),
        saved:  parseAmount($('.onb-g-saved',  row).value) ?? 0,
        target: parseAmount($('.onb-g-target', row).value) ?? 0,
      })).filter((g) => g.name && (g.saved > 0 || g.target > 0));
    }

    // ---------- Шаг 3: сводка введённого ----------
    function renderSummary() {
      const free  = parseAmount($('#onb-free').value) ?? 0;
      const goals = collectGoals();
      const saved = goals.reduce((s, g) => s + g.saved, 0);

      $('#onb-summary').innerHTML =
        '<div class="onb-sum-row">' +
        '<span>Свободные средства</span><b class="num">' + money(free) + ' ₽</b></div>' +
        goals.map((g) =>
          '<div class="onb-sum-row"><span>' + esc(g.name) + '</span>' +
          '<b class="num">' + money(g.saved) + ' ₽' +
          (g.target > 0 ? ' <i class="onb-sum-target">из ' + money(g.target) + ' ₽</i>' : '') +
          '</b></div>').join('') +
        '<div class="onb-sum-row onb-sum-total">' +
        '<span>В накоплениях всего</span><b class="num">' + money(saved) + ' ₽</b></div>';
    }

    // ---------- Отрисовка текущего шага ----------
    function paintStep() {
      steps.forEach((s) => { s.hidden = Number(s.dataset.step) !== step; });
      dots.forEach((d) => d.classList.toggle('active', Number(d.dataset.dot) <= step));
      $('#onb-back').hidden = step === 1;
      $('#onb-next').innerHTML = step === 3
        ? '<i class="fa-solid fa-check" aria-hidden="true"></i> Начать'
        : 'Далее <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>';
      hideError();
    }

    $('#onb-back').addEventListener('click', () => {
      if (step > 1) { step--; paintStep(); }
    });

    $('#onb-next').addEventListener('click', async () => {
      if (step === 1) {
        if (parseAmount($('#onb-free').value) === null) {
          return showError('Введите сумму цифрами или оставьте поле пустым');
        }
        step = 2;
      } else if (step === 2) {
        step = 3;
        renderSummary();
      } else {
        // Финальный шаг: сохраняем финансовое положение
        const free  = parseAmount($('#onb-free').value) ?? 0;
        const goals = collectGoals();
        const btn   = $('#onb-next');
        btn.disabled = true;
        try {
          await api('onboarding.save', {
            free,
            goals: JSON.stringify(goals),
          });
          location.href = 'index.php';          // на обзор
          return;
        } catch (err) {
          btn.disabled = false;
          showError(err.message);
        }
      }
      paintStep();
    });

    paintStep();
  }

  /* ============================================================
   * 10. Графики (общие помощники Chart.js)
   * ============================================================ */

  let charts = [];            // все созданные графики текущей страницы

  function addChart(chart) {
    charts.push(chart);
    return chart;
  }
  function destroyCharts() {
    charts.forEach((c) => c.destroy());
    charts = [];
  }

  // Настройки Chart.js по текущей теме
  function chartDefaults() {
    Chart.defaults.color = cssVar('--secondary', '#8ECBDF');
    Chart.defaults.borderColor = cssVar('--line', 'rgba(142,203,223,.1)');
    Chart.defaults.font.family =
      '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif';
  }

  const tooltipStyle = () => ({
    backgroundColor: cssVar('--panel-2', '#243644'),
    titleColor:      cssVar('--text', '#D7E3DC'),
    bodyColor:       cssVar('--secondary', '#8ECBDF'),
    borderColor:     cssVar('--line-hover', 'rgba(142,203,223,.3)'),
    borderWidth: 1,
    padding: 10,
    cornerRadius: 10,
    displayColors: false,
  });

  // Круговая диаграмма расходов по категориям
  function drawPie(canvasId, items, legendBoxId) {
    const cv = document.getElementById(canvasId);
    if (!cv) return;
    const box = cv.closest('.chart-box');

    // Пустое состояние: прячем canvas (но не удаляем — иначе после
    // смены темы график не восстановится) и показываем подсказку
    if (!items.length) {
      cv.style.display = 'none';
      let empty = box.querySelector('.chart-empty');
      if (!empty) {
        empty = document.createElement('div');
        empty.className = 'empty-state chart-empty';
        empty.style.padding = '30px 10px';
        empty.innerHTML =
          '<i class="fa-solid fa-chart-pie"></i>' +
          '<p>Пока нет данных</p>' +
          '<span>Добавьте операции — здесь появится диаграмма</span>';
        box.appendChild(empty);
      }
      if (legendBoxId) {
        const l = document.getElementById(legendBoxId);
        if (l) l.innerHTML = '';
      }
      return;
    }

    // Есть данные: вернуть canvas и убрать пустое состояние
    const empty = box.querySelector('.chart-empty');
    if (empty) empty.remove();
    cv.style.display = '';
    const ctx = cv.getContext('2d');

    const total = items.reduce((s, x) => s + x.sum, 0);
    addChart(new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: items.map((x) => x.name),
        datasets: [{
          data: items.map((x) => x.sum),
          backgroundColor: items.map((x) => withAlpha(x.color, .85)),
          hoverBackgroundColor: items.map((x) => x.color),
          borderWidth: 2,
          borderColor: cssVar('--panel', '#1C2A36'),
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '62%',
        plugins: {
          legend: { display: false },
          tooltip: {
            ...tooltipStyle(),
            callbacks: {
              label: (c) => ' ' + money(c.parsed) + ' ₽ · ' +
                Math.round(c.parsed * 100 / total) + '%',
            },
          },
        },
      },
    }));

    // Своя легенда под диаграммой
    if (legendBoxId) {
      const l = document.getElementById(legendBoxId);
      if (l) {
        l.innerHTML = items.slice(0, 8).map((x) => `
          <div class="pie-legend-item">
            <span class="dot" style="--c:${esc(x.color)}"></span>
            <span class="pl-name">${esc(x.name)}</span>
            <span class="pl-sum num">${money(x.sum)} ₽</span>
            <span class="pl-pct num">${Math.round(x.sum * 100 / total)}%</span>
          </div>`).join('');
      }
    }
  }

  /* ============================================================
   * 11. Страница «Обзор» (дашборд)
   * ============================================================ */

  // Период динамики: 6 месяцев / год / всё
  const dashState = { span: '6' };
  let dashBarsChart = null;

  // Столбчатая диаграмма: доходы и расходы по месяцам
  function drawDashBars(months, inc, exp) {
    const barBox = $('#dash-bars');
    if (!barBox) return;
    const accent  = cssVar('--accent', '#47A0DC');
    const warnCol = cssVar('--warn', '#E87A5C');
    const data = {
      labels: months,
      datasets: [
        { label: 'Доходы',  data: inc,
          backgroundColor: withAlpha(accent, .8),
          hoverBackgroundColor: accent, borderRadius: 8 },
        { label: 'Расходы', data: exp,
          backgroundColor: withAlpha(warnCol, .75),
          hoverBackgroundColor: warnCol, borderRadius: 8 },
      ],
    };
    // При смене периода обновляем данные существующего графика —
    // без пересоздания (иначе заметно мигание)
    if (dashBarsChart) {
      dashBarsChart.data = data;
      dashBarsChart.update();
      return;
    }
    dashBarsChart = addChart(new Chart(barBox.getContext('2d'), {
      type: 'bar',
      data,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { grid: { display: false }, border: { display: false } },
          y: { grid: { color: cssVar('--line', 'rgba(142,203,223,.1)') },
               border: { display: false }, ticks: { maxTicksLimit: 6 } },
        },
        plugins: {
          legend: { display: false },
          tooltip: { ...tooltipStyle(),
            callbacks: { label: (c) => c.dataset.label + ': ' + money(c.parsed.y) + ' ₽' } },
        },
      },
    }));
  }

  // Запрос данных только для динамики (при смене периода)
  async function refreshDashBars() {
    try {
      const d = await api('dashboard.get', { span: dashState.span });
      drawDashBars(d.months, d.seriesInc, d.seriesExp);
    } catch (err) {
      toast(err.message, true);
    }
  }

  // Переключатель «6 мес / Год / Всё» в шапке карточки динамики
  function initDashSpan() {
    const seg = $('#dash-span');
    if (!seg) return;
    seg.addEventListener('click', (e) => {
      const b = e.target.closest('.seg-btn');
      if (!b || b.dataset.span === dashState.span) return;
      dashState.span = b.dataset.span;
      $$('#dash-span .seg-btn').forEach((x) => x.classList.toggle('active', x === b));
      refreshDashBars();
    });
  }

  async function renderDashboard() {
    try {
      const d = await api('dashboard.get', { month: todayISO().slice(0, 7) });

      // Свободный баланс: доходы − расходы − отложено + возвращено
      const bal = $('#dash-balance');
      bal.classList.toggle('neg', d.balance < 0);
      countUp(bal, d.balance,
        (v) => (v < 0 ? '−' : '') + money(v));

      // Три сводки месяца (с анимацией подсчёта)
      countUp($('#dash-income'),  d.income,    (v) => money(v) + ' ₽');
      countUp($('#dash-expense'), d.expense,   (v) => money(v) + ' ₽');
      countUp($('#dash-saved'),   d.savedTotal, (v) => money(v) + ' ₽');

      // Диаграмма расходов по категориям (топ-8 + «Прочее»)
      let items = d.byCat.slice(0, 8);
      if (d.byCat.length > 8) {
        const rest = d.byCat.slice(8).reduce((s, x) => s + x.sum, 0);
        items.push({ name: 'Прочее', color: cssVar('--secondary', '#8ECBDF'), sum: Math.round(rest * 100) / 100 });
      }
      chartDefaults();
      destroyCharts();
      drawPie('dash-pie', items, 'dash-pie-legend', 'dash-pie-hint');

      // Столбчатая диаграмма: доходы и расходы по месяцам.
      // destroyCharts выше уничтожил прежний график — сбрасываем ссылку.
      dashBarsChart = null;
      drawDashBars(d.months, d.seriesInc, d.seriesExp);
    } catch (err) {
      toast(err.message, true);
    }
  }

  /* ============================================================
   * 12. Страницы «Доходы» / «Расходы»
   * ============================================================ */

  const txState = {
    type: 'expense',
    month: todayISO().slice(0, 7),
    txs: [],
  };

  // Сдвиг месяца на ±n
  function shiftMonth(ym, delta) {
    const [y, m] = ym.split('-').map(Number);
    const d = new Date(y, m - 1 + delta, 1);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
  }

  function renderTxRow(t) {
    return `
      <button class="tx" type="button" data-id="${t.id}">
        <span class="tx-icon" style="--c:${esc(t.color)}">
          <i class="fa-solid ${esc(t.icon)}"></i>
        </span>
        <span class="tx-main">
          <span class="tx-cat">${esc(t.cat_name)}</span>
          <span class="tx-comment">${esc(t.comment) || '&nbsp;'}</span>
        </span>
        <span class="tx-amount num ${t.type === 'income' ? 'is-income' : 'is-expense'}">
          ${t.type === 'income' ? '+' : ''}${money(t.amount)} ₽
        </span>
      </button>`;
  }

  async function renderTxPage() {
    const type = txState.type;

    // Название месяца в переключателе
    const label = $('#tx-month');
    if (label) label.textContent = monthTitle(txState.month);

    try {
      const [d, catAll] = await Promise.all([
        api('tx.list', { type, month: txState.month }),
        api('cat.list', { type }),                 // все категории пользователя
      ]);

      // Итог месяца (с анимацией подсчёта)
      countUp($('#tx-total'), d.total, (v) => money(v) + ' ₽');

      // Лента категорий: используемые за месяц — вперёд (по сумме),
      // затем остальные по алфавиту — любую можно открыть,
      // чтобы изменить или удалить категорию
      const sumsMap = new Map(d.cats.map((c) => [c.id, c.sum]));
      const catRows = catAll.cats
        .map((c) => ({ ...c, sum: sumsMap.get(c.id) || 0 }))
        .sort((a, b) =>
          ((b.sum > 0) - (a.sum > 0)) ||
          b.sum - a.sum ||
          a.name.localeCompare(b.name, 'ru'));

      const catBox = $('#tx-cats');
      catBox.innerHTML = catRows.map((c) => `
        <button class="cat-chip ${c.sum > 0 ? '' : 'cat-chip--zero'}" type="button" data-id="${c.id}">
          <span class="cat-chip-icon" style="--c:${esc(c.color)}">
            <i class="fa-solid ${esc(c.icon)}"></i>
          </span>
          <span class="cat-chip-name">${esc(c.name)}</span>
          <span class="cat-chip-sum num">${money(c.sum)} ₽</span>
        </button>`).join('') +
        `<button class="cat-chip cat-chip--add" type="button" id="js-cat-new">
           <span class="cat-chip-icon"><i class="fa-solid fa-plus"></i></span>
           <span class="cat-chip-name">Новая категория</span>
         </button>`;

      catBox.onclick = (e) => {
        const add = e.target.closest('#js-cat-new');
        if (add) {
          return openCategoryModal({ type, onSaved: renderTxPage });
        }
        const chip = e.target.closest('.cat-chip');
        if (chip) {
          const cat = catRows.find((c) => c.id === Number(chip.dataset.id));
          if (cat) openCategoryModal({ type, cat, onSaved: renderTxPage });
        }
      };

      // Список операций, сгруппированный по дням
      const list = $('#tx-list');
      if (!d.txs.length) {
        list.innerHTML =
          '<div class="card empty-state">' +
          '<i class="fa-solid ' + (type === 'income' ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down') + '"></i>' +
          '<p>В этом месяце пусто</p>' +
          '<span>Нажмите «Добавить ' + (type === 'income' ? 'доход' : 'расход') +
          '», чтобы создать первую операцию</span></div>';
        return;
      }

      // Группировка по дате + суммы за день
      const groups = [];
      let curDay = null;
      d.txs.forEach((t) => {
        if (!curDay || curDay.date !== t.tx_date) {
          curDay = { date: t.tx_date, txs: [], sum: 0 };
          groups.push(curDay);
        }
        curDay.txs.push(t);
        curDay.sum += t.amount;
      });

      list.innerHTML = groups.map((g) =>
        '<div class="tx-day-head"><b>' + dayTitleRu(g.date) + '</b>' +
        '<span class="num">' + money(g.sum) + ' ₽</span></div>' +
        g.txs.map(renderTxRow).join('')
      ).join('');

      list.onclick = (e) => {
        const btn = e.target.closest('.tx');
        if (!btn) return;
        const tx = d.txs.find((t) => t.id === Number(btn.dataset.id));
        if (tx) openTxModal({ type, tx, onSaved: renderTxPage });
      };
    } catch (err) {
      toast(err.message, true);
    }
  }

  // Быстрый переход по месяцам: модалка «Выбор месяца» — год со стрелками
  // и сетка месяцев. Будущие месяцы недоступны, назад — без ограничений
  // (кроме страховочного 2000 года).
  function openMonthPicker(current, onPick) {
    const nowYM = todayISO().slice(0, 7);
    const nowY  = Number(nowYM.slice(0, 4));
    const nowM  = Number(nowYM.slice(5, 7));
    let [year]  = current.split('-').map(Number);

    const draw = (el) => {
      $('.mp-year', el).textContent = year;
      $('[data-mp="prev"]', el).disabled = year <= 2000;
      $('[data-mp="next"]', el).disabled = year >= nowY;
      $$('.mp-m', el).forEach((b) => {
        const m = Number(b.dataset.m);
        b.disabled = year > nowY || (year === nowY && m > nowM);
        b.classList.toggle('active',
          year === Number(current.slice(0, 4)) && m === Number(current.slice(5, 7)));
      });
      $('#js-mp-now', el).hidden = current === nowYM;
    };

    openModal({
      title: 'Выбор месяца',
      body: `
        <div class="mp" id="js-mp">
          <div class="mp-year-row">
            <button class="btn-icon" type="button" data-mp="prev" aria-label="Год назад">
              <i class="fa-solid fa-chevron-left"></i>
            </button>
            <b class="mp-year num"></b>
            <button class="btn-icon" type="button" data-mp="next" aria-label="Год вперёд">
              <i class="fa-solid fa-chevron-right"></i>
            </button>
          </div>
          <div class="mp-grid">
            ${MONTHS_SHORT.map((m, i) =>
              `<button class="mp-m" type="button" data-m="${i + 1}">${m}</button>`).join('')}
          </div>
          <button class="btn btn-block" type="button" id="js-mp-now">Текущий месяц</button>
        </div>`,
      onOpen: (el, close) => {
        const pick = (y, m) => { close(); onPick(y + '-' + String(m).padStart(2, '0')); };
        $('[data-mp="prev"]', el).addEventListener('click', () => { year--; draw(el); });
        $('[data-mp="next"]', el).addEventListener('click', () => { year++; draw(el); });
        $('.mp-grid', el).addEventListener('click', (e) => {
          const b = e.target.closest('.mp-m');
          if (!b || b.disabled) return;
          pick(year, Number(b.dataset.m));
        });
        $('#js-mp-now', el).addEventListener('click', () =>
          pick(nowY, nowM));
        draw(el);
      },
    });
  }

  function initTxPage(type) {
    txState.type = type;
    txState.month = todayISO().slice(0, 7);

    // Явная кнопка добавления в шапке страницы
    $('#tx-add-btn').addEventListener('click', () => {
      openTxModal({ type, onSaved: renderTxPage });
    });

    // Клик по названию месяца — быстрый выбор любого месяца истории
    $('#tx-month').addEventListener('click', () => {
      openMonthPicker(txState.month, (ym) => {
        txState.month = ym;
        renderTxPage();
      });
    });

    $('#tx-prev').addEventListener('click', () => {
      if (txState.month <= '2000-01') return toast('Дальше истории нет', false);
      txState.month = shiftMonth(txState.month, -1);
      renderTxPage();
    });
    $('#tx-next').addEventListener('click', () => {
      // Будущее ограничиваем текущим месяцем — вперёд листать смысла нет
      const next = shiftMonth(txState.month, 1);
      if (next > todayISO().slice(0, 7)) return toast('Это ещё будущее', false);
      txState.month = next;
      renderTxPage();
    });

    renderTxPage();
  }

  /* ============================================================
   * 13. Страница «Накопления»
   * ============================================================ */

  // Карточка цели
  function goalCard(g) {
    const pct = Math.min(100, Math.round(g.saved * 100 / g.target));
    const done = g.saved >= g.target;
    return `
      <div class="card goal ${done ? 'done' : ''}" data-id="${g.id}">
        <div class="goal-head">
          <span class="goal-icon" style="--c:${esc(g.color)};color:${esc(g.color)}">
            <i class="fa-solid ${esc(g.icon)}"></i>
          </span>
          <div class="goal-title">
            <h3>${esc(g.name)}</h3>
            <span class="goal-date">Цель: ${money(g.target)} ₽</span>
          </div>
          ${done ? '<span class="goal-done"><i class="fa-solid fa-check"></i>Достигнута</span>' : ''}
        </div>

        <div class="goal-amounts">
          <span class="goal-current num">${money(g.saved)} ₽</span>
          ${done ? '' : '<span class="goal-target num">из ' + money(g.target) + ' ₽</span>'}
        </div>

        <div class="progress">
          <div class="progress-fill" data-w="${pct}"></div>
        </div>

        <div class="goal-foot">
          <span>${done ? 'Цель выполнена' : 'Осталось: ' + money(Math.max(0, g.target - g.saved)) + ' ₽'}</span>
          <span class="goal-pct num">${pct}%</span>
        </div>

        <div class="goal-actions">
          <button class="btn btn-sm btn-primary" type="button" data-op="in">
            <i class="fa-solid fa-plus"></i> Пополнить
          </button>
          <button class="btn btn-sm" type="button" data-op="out">
            <i class="fa-solid fa-minus"></i> Снять
          </button>
          <span class="flex-spacer"></span>
          <button class="btn-icon" type="button" data-act="edit" aria-label="Изменить цель">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button class="btn-icon" type="button" data-act="del" aria-label="Удалить цель">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </div>

        ${g.ops && g.ops.length ? '<div class="goal-history">' + renderGoalHistory(g) + '</div>' : ''}
      </div>`;
  }

  // Сколько последних операций цели показывать сразу (остальные — по кнопке)
  const GOAL_OPS_PREVIEW = 3;

  // Строка одной операции цели
  function opRowHtml(o) {
    return `
      <div class="op-row">
        <span class="op-ic ${o.op_type}">
          <i class="fa-solid ${o.op_type === 'in' ? 'fa-arrow-down' : 'fa-arrow-up'}"></i>
        </span>
        <span class="op-name">${esc(o.comment) || (o.op_type === 'in' ? 'Пополнение' : 'Снятие')}</span>
        <span class="op-date">${dtShort(o.created_at)}</span>
        <span class="op-amount num ${o.op_type}">
          ${o.op_type === 'in' ? '+' : '−'}${money(o.amount)} ₽
        </span>
      </div>`;
  }

  // Свёрнутая история цели: несколько последних операций без лишних
  // действий; если есть ещё — кнопка «Показать все» (возвращает только
  // внутренности, обёртка .goal-history — в goalCard)
  function renderGoalHistory(g) {
    const ops = g.ops || [];
    if (!ops.length) return '<div class="goal-history-empty">Операций пока нет</div>';

    let html = ops.slice(0, GOAL_OPS_PREVIEW).map(opRowHtml).join('');
    if (ops.length > GOAL_OPS_PREVIEW) {
      html += '<button class="btn-goal-hist" type="button" data-act="hist">' +
              '<i class="fa-solid fa-chevron-down"></i> Показать все операции (' +
              ops.length + ')</button>';
    }
    return html;
  }

  // Полная история цели: все операции без ограничений, сгруппированные
  // по месяцам — удобно при многолетней истории
  function renderGoalHistoryFull(g) {
    const ops = g.ops || [];
    const groups = [];
    let cur = null;
    ops.forEach((o) => {
      const ym = String(o.created_at || '').slice(0, 7);
      if (!cur || cur.ym !== ym) {
        cur = { ym, ops: [], sum: 0 };
        groups.push(cur);
      }
      cur.ops.push(o);
      cur.sum += (o.op_type === 'in' ? 1 : -1) * (Number(o.amount) || 0);
    });

    let html = '<div class="goal-hist-title">Вся история по месяцам</div>';
    groups.forEach((gr) => {
      const t  = monthTitle(gr.ym);
      const cap = t.charAt(0).toUpperCase() + t.slice(1);
      const net = Math.round(gr.sum * 100) / 100;
      html += '<div class="goal-hist-month"><span>' + esc(cap) + '</span>' +
              '<b class="num ' + (net >= 0 ? 'in' : 'out') + '">' +
              (net >= 0 ? '+' : '−') + money(Math.abs(net)) + ' ₽</b></div>';
      html += gr.ops.map(opRowHtml).join('');
    });
    html += '<button class="btn-goal-hist" type="button" data-act="hist">' +
            '<i class="fa-solid fa-chevron-up"></i> Свернуть</button>';
    return html;
  }

  async function renderSavings() {
    try {
      const d = await api('savings.list');
      countUp($('#sav-free'), d.balance, (v) => money(v) + ' ₽');

      const box = $('#goals-list');
      if (!d.goals.length) {
        box.innerHTML =
          '<div class="card empty-state"><i class="fa-solid fa-piggy-bank"></i>' +
          '<p>Целей пока нет</p>' +
          '<span>Создайте первую цель — и откладывайте на неё с баланса</span></div>';
        return;
      }
      box.innerHTML = d.goals.map(goalCard).join('');

      // Анимация заполнения прогресс-баров
      requestAnimationFrame(() => {
        $$('.progress-fill', box).forEach((el) => {
          el.style.width = el.dataset.w + '%';
        });
      });

      // Обработка кнопок карточки
      box.onclick = (e) => {
        const card = e.target.closest('.goal');
        if (!card) return;
        const goal = d.goals.find((g) => g.id === Number(card.dataset.id));

        const opBtn = e.target.closest('[data-op]');
        if (opBtn) return openSavingsOpModal(goal, opBtn.dataset.op, renderSavings);

        // Развернуть / свернуть полную историю операций цели
        if (e.target.closest('[data-act="hist"]')) {
          const wrap = card.querySelector('.goal-history');
          if (!wrap) return;
          const open = card.dataset.histOpen === '1';
          wrap.innerHTML = open ? renderGoalHistory(goal) : renderGoalHistoryFull(goal);
          card.dataset.histOpen = open ? '0' : '1';
          return;
        }

        if (e.target.closest('[data-act="edit"]')) {
          return openGoalModal(goal, renderSavings);
        }
        if (e.target.closest('[data-act="del"]')) {
          return confirmDialog(
            'Цель «' + goal.name + '» и все её операции будут удалены. ' +
            'Суммы вернутся в баланс согласно истории. Удалить?',
            async () => {
              try {
                await api('savings.delete', { id: goal.id });
                toast('Цель удалена');
                renderSavings();
              } catch (err) { toast(err.message, true); }
            });
        }
      };
    } catch (err) {
      toast(err.message, true);
    }
  }

  // Модалка пополнения / снятия
  function openSavingsOpModal(goal, dir, onDone) {
    const isIn = dir === 'in';
    openModal({
      title: (isIn ? 'Пополнить' : 'Снять') + ' — ' + goal.name,
      body: `
        <p class="op-hint">${isIn
          ? 'Деньги уйдут со свободного баланса в цель.'
          : 'Деньги вернутся из цели на свободный баланс.'}</p>
        <form id="js-op-form" novalidate autocomplete="off">
          <label class="field">
            <span class="field-label">Сумма</span>
            <span class="input-affix">
              <input type="text" id="js-op-amount" inputmode="decimal" placeholder="0">
              <span class="affix">₽</span>
            </span>
          </label>
          <label class="field">
            <span class="field-label">Комментарий</span>
            <input type="text" id="js-op-comment" maxlength="120"
                   placeholder="Необязательно">
          </label>
          <div style="display:flex;gap:10px">
            <button class="btn" type="button" id="js-op-cancel">Отмена</button>
            <button class="btn ${isIn ? 'btn-primary' : 'btn-danger'}" type="submit" style="flex:1">
              ${isIn ? 'Пополнить' : 'Снять'}
            </button>
          </div>
        </form>`,
      onOpen: (el, close) => {
        $('#js-op-cancel', el).addEventListener('click', close);
        $('#js-op-form', el).addEventListener('submit', async (e) => {
          e.preventDefault();
          const amount = $('#js-op-amount', el).value.replace(/\s/g, '').replace(',', '.');
          if (!(parseFloat(amount) > 0)) return toast('Введите сумму больше нуля', true);

          try {
            await api('savings.op', {
              id: goal.id, dir, amount,
              comment: $('#js-op-comment', el).value.trim(),
            });
            close();
            toast(isIn ? 'Пополнено' : 'Снято');
            onDone();
          } catch (err) {
            toast(err.message, true);
          }
        });
        $('#js-op-amount', el).focus();
      },
    });
  }

  // Модалка создания / изменения цели
  function openGoalModal(goal = null, onDone) {
    const isEdit = !!goal;
    let icon  = goal ? goal.icon  : 'fa-piggy-bank';
    let color = goal ? goal.color : COLORS[4];

    openModal({
      title: isEdit ? 'Изменить цель' : 'Новая цель',
      body: `
        <form id="js-goal-form" novalidate autocomplete="off">
          <label class="field">
            <span class="field-label">Название</span>
            <input type="text" id="js-goal-name" maxlength="40"
                   placeholder="Например, Отпуск" value="${isEdit ? esc(goal.name) : ''}">
          </label>
          <label class="field">
            <span class="field-label">Целевая сумма</span>
            <span class="input-affix">
              <input type="text" id="js-goal-target" inputmode="decimal"
                     placeholder="0" value="${isEdit ? goal.target : ''}">
              <span class="affix">₽</span>
            </span>
          </label>

          <span class="field-label">Иконка</span>
          <div class="icon-grid" id="js-goal-icons">
            ${ICONS.map((ic) => `
              <button class="icon-cell ${ic === icon ? 'active' : ''}" type="button"
                      data-icon="${ic}"><i class="fa-solid ${ic}"></i></button>`).join('')}
          </div>

          <span class="field-label" style="margin-top:14px">Цвет</span>
          <div class="swatches" id="js-goal-colors">
            ${COLORS.map((c) => `
              <button class="swatch ${c === color ? 'active' : ''}" type="button"
                      data-color="${c}" style="--c:${c}"></button>`).join('')}
          </div>

          <div style="margin-top:18px;display:flex;gap:10px">
            <button class="btn" type="button" id="js-goal-cancel">Отмена</button>
            <button class="btn btn-primary" type="submit" style="flex:1">
              ${isEdit ? 'Сохранить' : 'Создать'}
            </button>
          </div>
        </form>`,
      onOpen: (el, close) => {
        $('#js-goal-icons', el).addEventListener('click', (e) => {
          const b = e.target.closest('.icon-cell');
          if (!b) return;
          icon = b.dataset.icon;
          $$('.icon-cell', el).forEach((x) => x.classList.toggle('active', x === b));
        });
        $('#js-goal-colors', el).addEventListener('click', (e) => {
          const b = e.target.closest('.swatch');
          if (!b) return;
          color = b.dataset.color;
          $$('.swatch', el).forEach((x) => x.classList.toggle('active', x === b));
        });
        $('#js-goal-cancel', el).addEventListener('click', close);

        $('#js-goal-form', el).addEventListener('submit', async (e) => {
          e.preventDefault();
          const name   = $('#js-goal-name', el).value.trim();
          const target = $('#js-goal-target', el).value.replace(/\s/g, '').replace(',', '.');
          if (!name) return toast('Введите название цели', true);
          if (!(parseFloat(target) > 0)) return toast('Введите целевую сумму', true);

          try {
            if (isEdit) {
              await api('savings.update', { id: goal.id, name, target });
            } else {
              await api('savings.add', { name, target, icon, color });
            }
            close();
            toast(isEdit ? 'Цель обновлена' : 'Цель создана');
            onDone();
          } catch (err) {
            toast(err.message, true);
          }
        });
        $('#js-goal-name', el).focus();
      },
    });
  }

  function initSavingsPage() {
    $('#btn-add-goal').addEventListener('click', () => openGoalModal(null, renderSavings));
    renderSavings();
  }

  /* ============================================================
   * 14. Страница «Статистика»
   * ============================================================ */

  const statsState = { period: 'month', gran: 'day' };

  // Период -> диапазон дат YYYY-MM-DD
  function periodRange(period) {
    const now = new Date();
    const iso = (d) => d.getFullYear() + '-' +
      String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0');
    const to = new Date(now);
    const from = new Date(now);

    switch (period) {
      case 'week':  from.setDate(from.getDate() - 6); break;
      case 'month': from.setDate(1); break;
      case 'year':  from.setMonth(0, 1); break;
      // 'all' — берём максимальный горизонт, сервер подрежет по данным
      default:      from.setFullYear(from.getFullYear() - 20); break;
    }
    return { from: iso(from), to: iso(to) };
  }

  function renderTop(list) {
    const box = $('#st-top');
    if (!list.length) {
      box.innerHTML =
        '<div class="empty-state" style="padding:20px">' +
        '<i class="fa-solid fa-ranking-star"></i><p>Нет расходов за период</p>' +
        '<span>Как только появятся траты — покажем топ категорий</span></div>';
      return;
    }
    const max = list[0].sum || 1;
    box.innerHTML = list.map((x, i) => `
      <li>
        <div class="top-row">
          <span class="dot" style="--c:${esc(x.color)}"></span>
          <span class="top-name">${i + 1}. ${esc(x.name)}</span>
          <span class="top-pct num">${x.pct}%</span>
          <span class="top-sum num">${money(x.sum)} ₽</span>
        </div>
        <div class="top-bar">
          <i style="--c:${esc(x.color)}" data-w="${Math.round(x.sum * 100 / max)}"></i>
        </div>
      </li>`).join('');

    requestAnimationFrame(() => {
      $$('.top-bar i', box).forEach((el) => {
        el.style.width = el.dataset.w + '%';
      });
    });
  }

  async function renderStats() {
    let from, to;
    if (statsState.period === 'custom') {
      from = $('#st-from').value;
      to   = $('#st-to').value;
      if (!from || !to || from > to) return toast('Выберите корректный диапазон', true);
    } else {
      ({ from, to } = periodRange(statsState.period));
    }

    // Название периода над статистикой
    const label = $('#st-period-label');
    const fd = (iso) => { const [y, m, d] = iso.split('-'); return d + ' ' + MONTHS_SHORT[m - 1] + ' ' + y; };
    label.textContent = 'с ' + fd(from) + ' по ' + fd(to);

    try {
      const d = await api('stats.get', { from, to, gran: statsState.gran });

      // Итоги (с анимацией подсчёта)
      countUp($('#st-income'),  d.income,  (v) => money(v) + ' ₽');
      countUp($('#st-expense'), d.expense, (v) => money(v) + ' ₽');

      const net = $('#st-net');
      net.className = 'stat-value num ' + (d.net >= 0 ? 'pos' : 'neg');
      countUp(net, d.net, (v) => (v < 0 ? '−' : '+') + money(v) + ' ₽');

      // Средний расход в день (по количеству дней периода)
      const days = Math.max(1, Math.round(
        (new Date(d.to) - new Date(d.from)) / 86400000) + 1);
      $('#st-avg').dataset.num = '';   // среднее считается заново каждый раз
      countUp($('#st-avg'), d.expense / days, (v) => money(v) + ' ₽');

      // Топ-5 и структура расходов
      renderTop(d.top);
      chartDefaults();
      destroyCharts();
      drawPie('st-pie', d.pie, 'st-pie-legend', null);

      // Динамика трат: шаг выбирается кнопками (дни/недели/месяцы).
      // Сервер может подменить шаг на недели, если период слишком длинный.
      if (d.dGran && d.dGran !== statsState.gran) {
        statsState.gran = d.dGran;
        $$('#st-gran .seg-btn').forEach((x) =>
          x.classList.toggle('active', x.dataset.gran === statsState.gran));
      }

      const cv = document.getElementById('st-chart');
      if (cv) {
        const accent = cssVar('--accent', '#47A0DC');
        const ctx = cv.getContext('2d');
        const grad = ctx.createLinearGradient(0, 0, 0, cv.height || 240);
        grad.addColorStop(0, withAlpha(accent, .35));
        grad.addColorStop(1, withAlpha(accent, .02));

        addChart(new Chart(ctx, {
          type: 'line',
          data: {
            labels: d.dLabels,
            datasets: [{
              label: 'Расходы',
              data: d.dSeries,
              borderColor: accent,
              backgroundColor: grad,
              fill: true,
              tension: .35,
              pointRadius: d.dSeries.length > 40 ? 0 : 3,
              pointBackgroundColor: accent,
              borderWidth: 2.5,
            }],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { intersect: false, mode: 'index' },
            scales: {
              x: { grid: { display: false }, border: { display: false },
                   ticks: { maxTicksLimit: 8 } },
              y: { grid: { color: cssVar('--line', 'rgba(142,203,223,.1)') },
                   border: { display: false }, ticks: { maxTicksLimit: 6 } },
            },
            plugins: {
              legend: { display: false },
              tooltip: { ...tooltipStyle(),
                callbacks: { label: (c) => ' ' + money(c.parsed.y) + ' ₽' } },
            },
          },
        }));
      }
    } catch (err) {
      toast(err.message, true);
    }
  }

  function initStatsPage() {
    // Переключатель периода
    $('#st-seg').addEventListener('click', (e) => {
      const b = e.target.closest('.seg-btn');
      if (!b) return;
      statsState.period = b.dataset.period;
      $$('#st-seg .seg-btn').forEach((x) => x.classList.toggle('active', x === b));

      // Свой диапазон показываем только для режима «custom»
      $('#st-range').hidden = statsState.period !== 'custom';
      if (statsState.period === 'custom' && !$('#st-from').value) {
        const { from, to } = periodRange('month');
        $('#st-from').value = from;
        $('#st-to').value   = to;
      }
      renderStats();
    });

    $('#st-apply').addEventListener('click', renderStats);

    // Шаг динамики трат: дни / недели / месяцы
    $('#st-gran').addEventListener('click', (e) => {
      const b = e.target.closest('.seg-btn');
      if (!b || b.dataset.gran === statsState.gran) return;
      statsState.gran = b.dataset.gran;
      $$('#st-gran .seg-btn').forEach((x) => x.classList.toggle('active', x === b));
      renderStats();
    });

    renderStats();
  }

  /* ============================================================
   * 15. Кнопка добавления на «Обзоре» и запуск
   * ============================================================ */

  // «Добавить операцию» в шапке «Обзора»: тип выбирается в самой
  // модалке (расход по умолчанию), после сохранения обновим обзор
  function initDashAdd() {
    const btn = $('#dash-add-btn');
    if (!btn) return;
    btn.addEventListener('click', () => {
      openTxModal({
        type: 'expense',
        switchable: true,
        onSaved: renderDashboard,
      });
    });
  }

  // Перерисовка страницы (после смены темы или операции)
  window.__redrawPage = function () {
    const page = window.APP.page;
    if (page === 'dashboard') return renderDashboard();
    if (page === 'income')    return renderTxPage();
    if (page === 'expense')   return renderTxPage();
    if (page === 'savings')   return renderSavings();
    if (page === 'stats')     return renderStats();
  };

  // Точка входа: определяем страницу по body[data-page]
  function boot() {
    initTheme();
    initHeader();
    initAppClose();

    const page = window.APP.page;
    if (page === 'auth')        return initAuthPage();
    if (page === 'onboarding')  return initOnboarding();
    if (page === 'dashboard') { initDashAdd(); initDashSpan(); return renderDashboard(); }
    if (page === 'income')      return initTxPage('income');
    if (page === 'expense')     return initTxPage('expense');
    if (page === 'savings')     return initSavingsPage();
    if (page === 'stats')       return initStatsPage();
  }

  document.addEventListener('DOMContentLoaded', boot);

})();
