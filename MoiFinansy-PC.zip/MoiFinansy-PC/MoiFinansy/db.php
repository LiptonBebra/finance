<?php
// ============================================================
// db.php — ядро приложения: подключение SQLite, схема БД,
// общие помощники (сессия, CSRF, JSON-ответы, форматирование)
// ------------------------------------------------------------
// Это ЛОКАЛЬНОЕ приложение для ПК: база данных data/finance.db
// лежит рядом с кодом и создаётся автоматически при первом
// запуске вместе со всеми таблицами.
//
// Аккаунт упрощён: пользователь входит по ИМЕНИ, а для защиты
// данных может (по желанию) задать четырёхзначный PIN-код.
// Каждая таблица с данными пользователя содержит user_id —
// профили полностью изолированы друг от друга.
// ============================================================

// ---------- Сессия (запускаем один раз с безопасными параметрами) ----------

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 60 * 60 * 24 * 30,           // 30 дней
        'path'     => '/',
        'httponly' => true,                        // cookie недоступна из JS
        'samesite' => 'Lax',                       // защита от CSRF-переходов
    ]);
    session_start();
}

// ---------- Запасные реализации mb_* (если расширение mbstring выключено) ----------

if (!function_exists('mb_substr')) {
    function mb_substr($s, $start, $len = null) {
        $chars = preg_split('//u', (string)$s, -1, PREG_SPLIT_NO_EMPTY);
        return implode('', array_slice($chars, $start, $len));
    }
}

if (!function_exists('mb_strlen')) {
    function mb_strlen($s) {
        return count(preg_split('//u', (string)$s, -1, PREG_SPLIT_NO_EMPTY));
    }
}

// Запасное приведение к нижнему регистру (если mbstring выключен):
// сворачивает латиницу и всю русскую азбуку
if (!function_exists('mb_strtolower')) {
    function mb_strtolower($s) {
        $upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ';
        $lower = 'abcdefghijklmnopqrstuvwxyzабвгдеёжзийклмнопрстуфхцчшщъыьэюя';
        $map = array_combine(
            preg_split('//u', $upper, -1, PREG_SPLIT_NO_EMPTY),
            preg_split('//u', $lower, -1, PREG_SPLIT_NO_EMPTY)
        );
        return is_array($map) ? strtr((string)$s, $map) : strtolower((string)$s);
    }
}

// ---------- Подключение к базе данных ----------

// Путь к файлу БД (имя базы = имя файла)
define('DB_PATH', __DIR__ . '/data/finance.db');

// Создаём папку data/, если её ещё нет
$dataDir = dirname(DB_PATH);
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0775, true);
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH, null, null, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // ошибки — исключения
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,         // выборка ассоц. массивами
    ]);
    // Внешние ключи и WAL-режим (быстрее и надёжнее при параллельных запросах)
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA journal_mode = WAL');
} catch (PDOException $e) {
    http_response_code(500);
    exit('Ошибка подключения к базе данных');
}

// ============================================================
// Миграции со старых версий базы данных.
// Выполняются ДО создания схемы: таблицы старой версии могут
// иметь другие имена колонок, и создание индексов по новым
// колонкам упало бы. Порядок: users → transactions →
// savings_operations → savings (операции нужны для сверки сумм).
// ============================================================

/** Список колонок таблицы (пустой массив — таблицы нет) */
function table_cols(PDO $pdo, string $table): array
{
    // Имена таблиц задаются только в коде приложения,
    // поэтому подстановка в PRAGMA безопасна
    return array_column(
        $pdo->query("PRAGMA table_info($table)")->fetchAll(),
        'name'
    );
}

// ---------- 1. users: вход по телефону+паролю → имя+PIN ----------
$cols = table_cols($pdo, 'users');
if ($cols && in_array('phone', $cols, true)) {
    $pdo->exec('PRAGMA foreign_keys = OFF');
    $pdo->beginTransaction();
    try {
        $pdo->exec("
            CREATE TABLE users_new (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                name            TEXT    NOT NULL UNIQUE COLLATE NOCASE,
                pin_hash        TEXT,
                onboarded       INTEGER NOT NULL DEFAULT 0,
                initial_balance REAL    NOT NULL DEFAULT 0,
                created_at      TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            )
        ");
        // Старые пользователи уже работают с программой: мастер им не показываем
        $pdo->exec("
            INSERT INTO users_new (id, name, pin_hash, onboarded, initial_balance, created_at)
            SELECT id, name, NULL, 1, 0, created_at FROM users
        ");
        $pdo->exec('DROP TABLE users');
        $pdo->exec('ALTER TABLE users_new RENAME TO users');
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    } finally {
        $pdo->exec('PRAGMA foreign_keys = ON');
    }
}

// ---------- 2. transactions: колонка date → tx_date ----------
$txCols = table_cols($pdo, 'transactions');
if ($txCols && !in_array('tx_date', $txCols, true) && in_array('date', $txCols, true)) {
    $pdo->exec('ALTER TABLE transactions RENAME COLUMN date TO tx_date');
}

// ---------- 3. savings_operations: savings_id/type/date → saving_id/op_type/created_at ----------
$opCols = table_cols($pdo, 'savings_operations');
if ($opCols && (!in_array('op_type', $opCols, true) || !in_array('saving_id', $opCols, true))) {
    $pdo->beginTransaction();
    try {
        $pdo->exec('ALTER TABLE savings_operations RENAME TO savings_operations_old');
        $pdo->exec("
            CREATE TABLE savings_operations (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                saving_id  INTEGER NOT NULL REFERENCES savings(id) ON DELETE CASCADE,
                op_type    TEXT    NOT NULL CHECK (op_type IN ('in', 'out')),
                amount     REAL    NOT NULL CHECK (amount > 0),
                comment    TEXT    NOT NULL DEFAULT '',
                created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            )
        ");
        // deposit → «внесение» (in), всё остальное (withdraw) → «снятие» (out)
        $pdo->exec("
            INSERT INTO savings_operations (id, user_id, saving_id, op_type, amount, comment, created_at)
            SELECT id, user_id, savings_id,
                   CASE WHEN type = 'deposit' THEN 'in' ELSE 'out' END,
                   amount, '', date
            FROM savings_operations_old
        ");
        $pdo->exec('DROP TABLE savings_operations_old');
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ---------- 4. savings: current_amount → суммы считаются по операциям ----------
$savCols = table_cols($pdo, 'savings');
if ($savCols && in_array('current_amount', $savCols, true)) {
    // Сначала читаем старые строки: по ним сверим суммы с операциями
    $oldSavings = $pdo->query(
        'SELECT id, user_id, name, target_amount, current_amount FROM savings'
    )->fetchAll();

    $pdo->exec('PRAGMA foreign_keys = OFF');   // DROP savings_old заденет
                                               // FK переименованных таблиц
    $pdo->beginTransaction();
    try {
        $pdo->exec('ALTER TABLE savings RENAME TO savings_old');
        $pdo->exec("
            CREATE TABLE savings (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                name          TEXT    NOT NULL,
                target_amount REAL    NOT NULL CHECK (target_amount > 0),
                icon          TEXT    NOT NULL DEFAULT 'fa-piggy-bank',
                color         TEXT    NOT NULL DEFAULT '#E3A95C',
                created_at    TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
            )
        ");
        $pdo->exec("
            INSERT INTO savings (id, user_id, name, target_amount, icon, color, created_at)
            SELECT id, user_id, name, target_amount, 'fa-piggy-bank', '#E3A95C', created_at
            FROM savings_old
        ");
        $pdo->exec('DROP TABLE savings_old');

        // Сверка: если сумма операций не совпадает с current_amount из
        // старой версии — добавляем корректирующую операцию (current_amount
        // был «истиной» в старой версии)
        $sumSt = $pdo->prepare(
            "SELECT COALESCE(SUM(CASE WHEN op_type = 'in' THEN amount ELSE -amount END), 0)
             FROM savings_operations WHERE saving_id = ?"
        );
        $addOp = $pdo->prepare(
            'INSERT INTO savings_operations (user_id, saving_id, op_type, amount, comment)
             VALUES (?, ?, ?, ?, ?)'
        );
        foreach ($oldSavings as $s) {
            $sumSt->execute([(int)$s['id']]);
            $diff = round((float)$s['current_amount'] - (float)$sumSt->fetchColumn(), 2);
            if ($diff > 0) {
                $addOp->execute([$s['user_id'], $s['id'], 'in', $diff, 'Начальный остаток']);
            } elseif ($diff < 0) {
                $addOp->execute([$s['user_id'], $s['id'], 'out', -$diff, 'Коррекция старых данных']);
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    } finally {
        $pdo->exec('PRAGMA foreign_keys = ON');
    }
}

// ============================================================
// Схема базы данных (создаёт недостающие таблицы и индексы)
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS users (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT    NOT NULL UNIQUE COLLATE NOCASE, -- имя = логин (без учёта регистра)
        pin_hash        TEXT,                            -- хеш 4-значного PIN (может не быть)
        onboarded       INTEGER NOT NULL DEFAULT 0,      -- пройден ли мастер первого входа
        initial_balance REAL    NOT NULL DEFAULT 0,       -- стартовые средства на момент знакомства
        created_at      TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS categories (
        id      INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        type    TEXT    NOT NULL CHECK (type IN ('income', 'expense')),
        name    TEXT    NOT NULL,
        icon    TEXT    NOT NULL DEFAULT 'fa-ellipsis',
        color   TEXT    NOT NULL DEFAULT '#47A0DC',
        UNIQUE (user_id, type, name)                   -- у одного пользователя имена не повторяются
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
        type        TEXT    NOT NULL CHECK (type IN ('income', 'expense')),
        amount      REAL    NOT NULL CHECK (amount > 0),
        comment     TEXT    NOT NULL DEFAULT '',
        tx_date     TEXT    NOT NULL,                  -- дата операции (YYYY-MM-DD)
        created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS savings (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        name          TEXT    NOT NULL,
        target_amount REAL    NOT NULL CHECK (target_amount > 0),
        icon          TEXT    NOT NULL DEFAULT 'fa-piggy-bank',
        color         TEXT    NOT NULL DEFAULT '#E3A95C',
        created_at    TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS savings_operations (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        saving_id  INTEGER NOT NULL REFERENCES savings(id) ON DELETE CASCADE,
        op_type    TEXT    NOT NULL CHECK (op_type IN ('in', 'out')),
        amount     REAL    NOT NULL CHECK (amount > 0),
        comment    TEXT    NOT NULL DEFAULT '',
        created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE INDEX IF NOT EXISTS idx_tx_user_date    ON transactions(user_id, tx_date);
    CREATE INDEX IF NOT EXISTS idx_tx_user_cat     ON transactions(user_id, category_id);
    CREATE INDEX IF NOT EXISTS idx_tx_user_type_date ON transactions(user_id, type, tx_date);
    CREATE INDEX IF NOT EXISTS idx_cat_user        ON categories(user_id, type);
    CREATE INDEX IF NOT EXISTS idx_sav_user        ON savings(user_id);
    CREATE INDEX IF NOT EXISTS idx_savop_user_goal ON savings_operations(user_id, saving_id);
    CREATE INDEX IF NOT EXISTS idx_savop_goal_date ON savings_operations(saving_id, op_type, created_at);
");

// ============================================================
// Помощники, общие для index.php и api.php
// ============================================================

/** Идентификатор текущего пользователя или null (не авторизован) */
function current_user_id(): ?int
{
    return isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : null;
}

/** CSRF-токен сессии (создаётся при первом обращении) */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

/** Проверка CSRF-токена из заголовка или поля формы */
function csrf_check(): void
{
    $sent = $_POST['csrf']
        ?? $_SERVER['HTTP_X_CSRF_TOKEN']
        ?? '';
    if (!hash_equals(csrf_token(), (string)$sent)) {
        json_reply(['ok' => false, 'error' => 'Сессия устарела, обновите страницу'], 403);
    }
}

/** Единый JSON-ответ API + завершение скрипта */
function json_reply(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Поиск профиля по имени без учёта регистра (имя = логин) */
function find_user_by_name(PDO $pdo, string $name): ?array
{
    $st = $pdo->prepare('SELECT * FROM users WHERE name = ? COLLATE NOCASE');
    $st->execute([$name]);
    $user = $st->fetch() ?: null;

    // COLLATE NOCASE в SQLite сворачивает только латиницу, поэтому для
    // русских имён («Иван» vs «иван») сравниваем в PHP повторно
    if ($user === null) {
        $want = mb_strtolower($name, 'UTF-8');
        foreach ($pdo->query('SELECT * FROM users')->fetchAll() as $row) {
            if (mb_strtolower((string)$row['name'], 'UTF-8') === $want) {
                return $row;
            }
        }
    }
    return $user;
}

/**
 * Свободный баланс пользователя:
 *   стартовые средства + доходы − расходы − отложено + возвращено.
 * «Стартовые средства» (initial_balance) задаёт мастер первого входа:
 * это всё, что было у человека на момент знакомства с программой
 * (и свободные деньги, и то, что уже лежит в накоплениях — отложенное
 * далее вычитается операциями «in», поэтому баланс не задваивается).
 */
function user_balance(PDO $pdo, int $uid): float
{
    $st = $pdo->prepare(
        "SELECT
           (SELECT COALESCE(initial_balance, 0) FROM users WHERE id = ?)
         + (SELECT COALESCE(SUM(amount), 0) FROM transactions
             WHERE user_id = ? AND type = 'income')
         - (SELECT COALESCE(SUM(amount), 0) FROM transactions
             WHERE user_id = ? AND type = 'expense')
         - (SELECT COALESCE(SUM(amount), 0) FROM savings_operations
             WHERE user_id = ? AND op_type = 'in')
         + (SELECT COALESCE(SUM(amount), 0) FROM savings_operations
             WHERE user_id = ? AND op_type = 'out')"
    );
    $st->execute([$uid, $uid, $uid, $uid, $uid]);
    return round((float)$st->fetchColumn(), 2);
}

/** Сколько всего отложено пользователем (сумма текущих сумм всех целей) */
function user_saved_total(PDO $pdo, int $uid): float
{
    $st = $pdo->prepare(
        "SELECT COALESCE(SUM(
            (SELECT COALESCE(SUM(amount), 0) FROM savings_operations o
              WHERE o.saving_id = s.id AND o.op_type = 'in')
          - (SELECT COALESCE(SUM(amount), 0) FROM savings_operations o
              WHERE o.saving_id = s.id AND o.op_type = 'out')
        ), 0)
        FROM savings s WHERE s.user_id = ?"
    );
    $st->execute([$uid]);
    return round((float)$st->fetchColumn(), 2);
}
