<?php
// ============================================================
// index.php — единая точка входа: маршрутизация страниц,
// проверка авторизации, общий каркас (шапка + навигация)
// ------------------------------------------------------------
// Страницы: dashboard (обзор), income (доходы), expense
// (расходы), savings (накопления), stats (статистика),
// onboarding (мастер первого входа).
// Неавторизованного пользователя всегда встречает экран входа,
// а новый профиль — мастер настройки финансового положения.
// ============================================================

require __DIR__ . '/db.php';

// ---------- Определяем запрошенную страницу ----------

$page = (string)($_GET['page'] ?? 'dashboard');
$uid  = current_user_id();

// ---------- Неавторизованный пользователь → экран входа ----------

$authPages = ['auth'];
if (!$uid && !in_array($page, $authPages, true)) {
    $page = 'auth';
}

// Разрешённые страницы (белый список)
$known = ['dashboard', 'income', 'expense', 'savings', 'stats', 'onboarding', 'auth'];
if (!in_array($page, $known, true)) {
    $page = $uid ? 'dashboard' : 'auth';
}

$userName   = '';
$onboarded  = 1;
if ($uid) {

    // Уже вошли — экран входа не нужен, ведём в обзор
    if ($page === 'auth') {
        header('Location: index.php?page=dashboard');
        exit;
    }

    $st = $pdo->prepare('SELECT name, onboarded FROM users WHERE id = ?');
    $st->execute([$uid]);
    $row      = $st->fetch();
    $userName = $row ? $row['name'] : '';
    if ($userName === '') {           // страховка: профиль удалён, а сессия жива
        session_destroy();
        header('Location: index.php?page=auth');
        exit;
    }
    $onboarded = (int)$row['onboarded'];

    // Новый профиль не прошёл мастер первого входа — ведём его туда;
    // кто уже прошёл — мастер больше не показываем.
    if (!$onboarded && $page !== 'onboarding') {
        header('Location: index.php?page=onboarding');
        exit;
    }
    if ($onboarded && $page === 'onboarding') {
        header('Location: index.php?page=dashboard');
        exit;
    }
}

// Заголовок и подзаголовок текущей страницы (для шапки контента)
$meta = [
    'dashboard'  => ['Обзор',            'Ваши финансы на одном экране'],
    'income'     => ['Доходы',           'Операции пополнения за месяц'],
    'expense'    => ['Расходы',          'Траты за месяц'],
    'savings'    => ['Накопления',       'Цели и движение средств'],
    'stats'      => ['Статистика',       'Анализ за выбранный период'],
    'onboarding' => ['Добро пожаловать', 'Настроим ваш финансовый старт'],
    'auth'       => ['Мои финансы',      'Учёт доходов, расходов и целей'],
];
[$pageTitle] = $meta[$page];
?>
<!DOCTYPE html>
<html lang="ru" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#0D1720">
    <title><?= htmlspecialchars($pageTitle) ?> — Мои финансы</title>

    <!-- Значок приложения (используется и установщиком на Windows) -->
    <link rel="icon" type="image/png" href="assets/img/icon.png">

    <!-- Ранняя установка темы из localStorage: без «вспышки» при загрузке -->
    <script>
        (function () {
            try {
                var t = localStorage.getItem('fin-theme');
                if (t === 'light' || t === 'dark') {
                    document.documentElement.setAttribute('data-theme', t);
                }
            } catch (e) { /* приватный режим — остаётся тёмная */ }
        })();
    </script>

    <!-- Иконки Font Awesome и графики Chart.js (CDN) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>

    <!-- ?v= по времени изменения файла: после обновления приложения
         WebView2 и браузер гарантированно грузят свежие стили и скрипт -->
    <link rel="stylesheet" href="assets/css/style.css?v=<?= filemtime(__DIR__ . '/assets/css/style.css') ?>">
</head>
<?php
// Класс тела: полноэкранные страницы (вход, мастер) центрируются,
// остальные получают каркас «шапка + контент + навигация».
$bodyClass = in_array($page, ['auth', 'onboarding'], true) ? 'is-auth' : 'is-app';
?>
<body class="<?= $bodyClass ?>" data-page="<?= htmlspecialchars($page) ?>">

<?php if ($page === 'auth'): ?>
    <?php require __DIR__ . '/views/auth.php'; ?>

<?php elseif ($page === 'onboarding'): ?>
    <?php require __DIR__ . '/views/onboarding.php'; ?>

<?php else: ?>
    <!-- Фоновое свечение -->
    <div class="bg-glow" aria-hidden="true"></div>

    <!-- ---------- Верхняя панель ---------- -->
    <header class="topbar">
        <div class="topbar-in">
            <div class="greet">
                <div class="greet-avatar"><?= htmlspecialchars(mb_substr($userName, 0, 1)) ?></div>
                <div class="greet-text">
                    <!-- Приветствие подставит JS по времени суток -->
                    <span class="greet-hello" id="greet-hello">Привет</span>
                    <span class="greet-name"><?= htmlspecialchars($userName) ?></span>
                </div>
            </div>

            <div class="topbar-right">
                <!-- Полная дата: день недели + «30 октября 2026» -->
                <div class="topbar-date" id="topbar-date">
                    <span class="d-wd">&nbsp;</span>
                    <span class="d-full">&nbsp;</span>
                </div>

                <div class="topbar-actions">
                    <!-- Закрыть приложение: видно только в режиме приложения -->
                    <button class="topbar-btn app-close" id="app-close" type="button"
                            title="Закрыть приложение" aria-label="Закрыть приложение">
                        <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                    </button>
                    <!-- Переключатель темы -->
                    <button class="topbar-btn" id="theme-toggle" type="button"
                            title="Сменить тему" aria-label="Сменить тему">
                        <i class="fa-solid fa-sun" aria-hidden="true"></i>
                    </button>
                    <!-- Выход -->
                    <a class="topbar-btn" id="logout-btn"
                       href="api.php?action=auth.logout" title="Выйти" aria-label="Выйти">
                        <i class="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- ---------- Контент страницы ---------- -->
    <main class="app">
        <?php
        require __DIR__ . '/views/' . $page . '.php';
        ?>
    </main>

    <!-- ---------- Навигация: сайдбар на ПК / таб-бар на телефоне ---------- -->
    <nav class="tabbar" aria-label="Разделы">
        <!-- Бренд виден только в режиме сайдбара (на ПК) -->
        <div class="tabbar-brand" aria-hidden="true">
            <span class="tabbar-brand-logo"><i class="fa-solid fa-wallet"></i></span>
            <span class="tabbar-brand-name">Мои финансы</span>
        </div>
        <?php
        $tabs = [
            'dashboard' => ['fa-house',              'Обзор'],
            'income'    => ['fa-arrow-trend-up',     'Доходы'],
            'expense'   => ['fa-arrow-trend-down',   'Расходы'],
            'savings'   => ['fa-piggy-bank',         'Накопления'],
            'stats'     => ['fa-chart-pie',          'Статистика'],
        ];
        foreach ($tabs as $key => [$icon, $label]): ?>
            <a class="tab <?= $page === $key ? 'active' : '' ?>"
               href="index.php?page=<?= $key ?>">
                <i class="fa-solid <?= $icon ?>" aria-hidden="true"></i>
                <span><?= $label ?></span>
            </a>
        <?php endforeach; ?>
    </nav>
<?php endif; ?>

<!-- Контейнер тостов -->
<div id="toast-root" aria-live="polite"></div>

<!-- Общие данные для JS -->
<script>
    window.APP = {
        page:      <?= json_encode($page) ?>,
        isAuth:    <?= $uid ? 'true' : 'false' ?>,
        userName:  <?= json_encode($userName) ?>,
        onboarded: <?= $onboarded ? 'true' : 'false' ?>,
        csrf:      <?= json_encode(csrf_token()) ?>
    };
</script>
<script src="assets/js/app.js?v=<?= filemtime(__DIR__ . '/assets/js/app.js') ?>"></script>
</body>
</html>
