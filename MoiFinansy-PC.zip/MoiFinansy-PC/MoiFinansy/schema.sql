-- ============================================================
--  Мои финансы — структура базы данных (SQLite)
--
--  Файл справочный: db.php создаёт эти таблицы автоматически
--  при первом запуске приложения. Ручной импорт не требуется,
--  но скрипт может пригодиться для восстановления схемы.
--
--  Это локальное приложение для ПК: профиль создаётся по имени,
--  данные каждого профиля привязаны к user_id и изолированы.
-- ============================================================

-- Профили (вход по имени, при желании — 4-значный PIN-код)
CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT    NOT NULL UNIQUE COLLATE NOCASE,     -- имя = логин (без учёта регистра)
    pin_hash        TEXT,                                       -- password_hash(PIN), может быть NULL
    onboarded       INTEGER NOT NULL DEFAULT 0,                 -- пройден ли мастер первого входа
    initial_balance REAL    NOT NULL DEFAULT 0,                 -- стартовые средства (свободные + накопления)
    created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Категории доходов и расходов (свой набор у каждого профиля)
CREATE TABLE IF NOT EXISTS categories (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,   -- владелец
    type    TEXT    NOT NULL CHECK (type IN ('income', 'expense')),     -- income | expense
    name    TEXT    NOT NULL,                                           -- название
    icon    TEXT    NOT NULL DEFAULT 'fa-ellipsis',                     -- иконка Font Awesome (fa-…)
    color   TEXT    NOT NULL DEFAULT '#47A0DC',                         -- цвет #rrggbb
    UNIQUE (user_id, type, name)                                        -- без дублей
);

-- Операции (доходы и расходы)
CREATE TABLE IF NOT EXISTS transactions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,       -- владелец
    type        TEXT    NOT NULL CHECK (type IN ('income', 'expense')),        -- тип операции
    category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,  -- категория
    amount      REAL    NOT NULL CHECK (amount > 0),                  -- сумма
    comment     TEXT    NOT NULL DEFAULT '',                          -- комментарий (необязательно)
    tx_date     TEXT    NOT NULL,                                     -- YYYY-MM-DD
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Цели накоплений
CREATE TABLE IF NOT EXISTS savings (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, -- владелец
    name          TEXT NOT NULL,                                           -- название цели
    target_amount REAL NOT NULL CHECK (target_amount > 0),                 -- целевая сумма
    icon          TEXT NOT NULL DEFAULT 'fa-piggy-bank',                   -- иконка Font Awesome
    color         TEXT NOT NULL DEFAULT '#E3A95C',                         -- цвет #rrggbb
    created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- История пополнений и снятий по целям
-- (текущая сумма цели = Σ «in» − Σ «out» по операциям)
CREATE TABLE IF NOT EXISTS savings_operations (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,     -- владелец
    saving_id  INTEGER NOT NULL REFERENCES savings(id) ON DELETE CASCADE,   -- цель
    op_type    TEXT    NOT NULL CHECK (op_type IN ('in', 'out')),    -- пополнение | снятие
    amount     REAL    NOT NULL CHECK (amount > 0),                  -- сумма операции
    comment    TEXT    NOT NULL DEFAULT '',                          -- комментарий
    created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Индексы для частых выборок (списки, статистика)
CREATE INDEX IF NOT EXISTS idx_tx_user_date      ON transactions(user_id, tx_date);
CREATE INDEX IF NOT EXISTS idx_tx_user_cat       ON transactions(user_id, category_id);
CREATE INDEX IF NOT EXISTS idx_tx_user_type_date ON transactions(user_id, type, tx_date);
CREATE INDEX IF NOT EXISTS idx_cat_user          ON categories(user_id, type);
CREATE INDEX IF NOT EXISTS idx_sav_user          ON savings(user_id);
CREATE INDEX IF NOT EXISTS idx_savop_user_goal   ON savings_operations(user_id, saving_id);
CREATE INDEX IF NOT EXISTS idx_savop_goal_date   ON savings_operations(saving_id, op_type, created_at);
