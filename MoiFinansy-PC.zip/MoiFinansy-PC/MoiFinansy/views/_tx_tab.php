<?php
// ============================================================
// views/_tx_tab.php — общий шаблон страниц «Доходы» и «Расходы»
// ------------------------------------------------------------
// Переменные, задаваемые из income.php / expense.php:
//   $pageType  — 'income' | 'expense'
// Данные (операции месяца, суммы по категориям) подтягивает
// JS через tx.list. Клик по операции — редактирование.
// ============================================================
?>

<!-- Заголовок страницы -->
<section class="page-head reveal" style="--d:0">
    <div>
        <h1><?= $pageType === 'income' ? 'Доходы' : 'Расходы' ?></h1>
        <p class="page-sub">Итого за месяц: <b class="num" id="tx-total">—</b></p>
    </div>
    <div class="page-head-side">
        <!-- Явная кнопка добавления операции -->
        <button class="btn btn-primary" id="tx-add-btn" type="button">
            <i class="fa-solid fa-plus" aria-hidden="true"></i>
            <?= $pageType === 'income' ? 'Добавить доход' : 'Добавить расход' ?>
        </button>
        <!-- Переключатель месяца -->
        <div class="month-nav">
            <button class="btn-icon" id="tx-prev" type="button" aria-label="Предыдущий месяц">
                <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
            </button>
            <span class="month-name" id="tx-month">…</span>
            <button class="btn-icon" id="tx-next" type="button" aria-label="Следующий месяц">
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
            </button>
        </div>
    </div>
</section>

<!-- Лента категорий с суммами за месяц -->
<section class="reveal" style="--d:1">
    <h2 class="section-title">Категории
        <span class="section-note">суммы за месяц</span>
    </h2>
    <div class="cat-scroll" id="tx-cats">
        <span class="skeleton skeleton-text"></span>
    </div>
</section>

<!-- Список операций по дням -->
<section class="reveal" style="--d:2">
    <h2 class="section-title">Операции
        <span class="section-note">нажмите, чтобы изменить</span>
    </h2>
    <div id="tx-list" class="tx-list">
        <span class="skeleton skeleton-text"></span>
    </div>
</section>
