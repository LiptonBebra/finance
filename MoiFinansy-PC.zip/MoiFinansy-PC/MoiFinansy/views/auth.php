<?php
// ============================================================
// views/auth.php — экран входа и регистрации
// ------------------------------------------------------------
// Это локальное приложение, поэтому вход максимально простой:
//   шаг 1 — пользователь вводит имя;
//   шаг 2 — если профиль новый, предлагается задать
//           четырёхзначный PIN-код (можно пропустить),
//           если существующий — вводится его PIN.
// Экран декорирован мягкими кругами, PIN вводится с экранной
// клавиатуры (нумпада). Отправка — fetch на api.php.
// ============================================================
?>
<div class="auth-wrap">

    <!-- Круглый декор фона -->
    <div class="auth-decor" aria-hidden="true">
        <span class="c1"></span>
        <span class="c2"></span>
        <span class="c3"></span>
        <span class="c4"></span>
        <span class="c5"></span>
    </div>

    <!-- Кнопка темы над карточкой -->
    <button class="topbar-btn auth-theme" id="theme-toggle" type="button"
            title="Сменить тему" aria-label="Сменить тему">
        <i class="fa-solid fa-sun" aria-hidden="true"></i>
    </button>

    <!-- Закрыть приложение: видно только в режиме приложения -->
    <button class="topbar-btn auth-theme app-close" id="app-close" type="button"
            title="Закрыть приложение" aria-label="Закрыть приложение">
        <i class="fa-solid fa-xmark" aria-hidden="true"></i>
    </button>

    <div class="card auth-card">
        <div class="auth-brand">
            <div class="auth-logo"><i class="fa-solid fa-wallet" aria-hidden="true"></i></div>
            <h1>Мои финансы</h1>
            <p id="auth-subtitle">Доходы, расходы и цели накоплений</p>
        </div>

        <!-- ---------- Шаг 1: имя ---------- -->
        <form class="auth-form" id="form-name" novalidate autocomplete="off">
            <label class="field">
                <span class="field-label">Как вас зовут?</span>
                <input type="text" name="name" id="auth-name" required
                       maxlength="40" placeholder="Да-да здесь свое имя"
                       autocomplete="off">
            </label>

            <p class="form-error" id="auth-error" hidden></p>

            <button class="btn btn-primary btn-block" type="submit" id="btn-name-continue">
                Продолжить
                <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
            </button>
        </form>

        <!-- ---------- Шаг 2а: вход по PIN ---------- -->
        <div class="auth-step" id="step-login" hidden>
            <p class="auth-hello">С возвращением, <b id="login-hello-name"></b>!</p>

            <!-- Индикатор из четырёх точек -->
            <div class="pin-dots" id="pin-dots-login" aria-hidden="true">
                <span class="pin-dot"></span>
                <span class="pin-dot"></span>
                <span class="pin-dot"></span>
                <span class="pin-dot"></span>
            </div>

            <p class="form-error" id="login-error" hidden></p>

            <!-- Экранная клавиатура PIN-кода -->
            <div class="pin-pad" id="pin-pad-login" aria-label="Клавиатура PIN-кода"></div>

            <button class="btn btn-ghost btn-block" type="button" id="btn-back-login">
                <i class="fa-solid fa-arrow-left" aria-hidden="true"></i>
                Это не я
            </button>
        </div>

        <!-- ---------- Шаг 2б: новый профиль + предложение PIN ---------- -->
        <div class="auth-step" id="step-register" hidden>
            <p class="auth-hello">Приятно познакомиться, <b id="reg-hello-name"></b>!</p>
            <p class="auth-pin-hint">
                Для защиты данных предлагаем установить четырёхзначный
                PIN-код — он будет запрашиваться при каждом входе.
            </p>

            <div class="pin-dots" id="pin-dots-reg" aria-hidden="true">
                <span class="pin-dot"></span>
                <span class="pin-dot"></span>
                <span class="pin-dot"></span>
                <span class="pin-dot"></span>
            </div>

            <p class="form-error" id="reg-error" hidden></p>

            <div class="pin-pad" id="pin-pad-reg" aria-label="Клавиатура PIN-кода"></div>

            <button class="btn btn-primary btn-block" type="button" id="btn-register">
                <i class="fa-solid fa-user-plus" aria-hidden="true"></i>
                Создать профиль
            </button>
            <button class="btn btn-ghost btn-block" type="button" id="btn-skip-pin">
                Продолжить без PIN-кода
            </button>
            <button class="btn btn-ghost btn-block" type="button" id="btn-back-register">
                <i class="fa-solid fa-arrow-left" aria-hidden="true"></i>
                Назад
            </button>
        </div>

        <p class="auth-footnote">
            Приложение работает локально: все данные хранятся на вашем
            компьютере в базе SQLite.
        </p>
    </div>
</div>
