<?php
// ============================================================
// views/dashboard.php — обзор: баланс, сводки за месяц,
// круговая диаграмма расходов, динамика (6 мес / год / всё).
// Данные подтягивает JS (dashboard.get).
// ============================================================
?>

<!-- Заголовок страницы + кнопка добавления -->
<section class="page-head reveal" style="--d:0">
    <div>
        <h1>Обзор</h1>
        <p class="page-sub">Ваши финансы на одном экране</p>
    </div>
    <div class="page-head-side">
        <!-- Единственная кнопка добавления операции: тип выбирается в окне -->
        <button class="btn btn-primary" id="dash-add-btn" type="button">
            <i class="fa-solid fa-plus" aria-hidden="true"></i>
            Добавить операцию
        </button>
    </div>
</section>

<!-- Герой: свободный баланс -->
<section class="card hero reveal" style="--d:1">
    <div class="hero-label">
        <i class="fa-solid fa-scale-balanced" aria-hidden="true"></i>
        Свободный баланс
    </div>
    <div class="hero-balance">
        <span class="num" id="dash-balance"><span class="skeleton skeleton-text"></span></span> <span class="hero-cur">₽</span>
    </div>
    <p class="hero-sub" id="dash-balance-sub">Доходы минус расходы и отложенные суммы</p>
</section>

<!-- Три сводные карточки за месяц -->
<section class="grid-3 reveal" style="--d:2">
    <div class="card mini">
        <div class="mini-icon inc"><i class="fa-solid fa-arrow-trend-up" aria-hidden="true"></i></div>
        <div class="mini-label">Доходы<br>за месяц</div>
        <div class="mini-value num" id="dash-income">—</div>
    </div>
    <div class="card mini">
        <div class="mini-icon exp"><i class="fa-solid fa-arrow-trend-down" aria-hidden="true"></i></div>
        <div class="mini-label">Расходы<br>за месяц</div>
        <div class="mini-value num" id="dash-expense">—</div>
    </div>
    <div class="card mini">
        <div class="mini-icon sav"><i class="fa-solid fa-piggy-bank" aria-hidden="true"></i></div>
        <div class="mini-label">В накоплениях<br>всего</div>
        <div class="mini-value num" id="dash-saved">—</div>
    </div>
</section>

<!-- Круговая диаграмма расходов по категориям -->
<section class="card chart-card reveal" style="--d:3">
    <div class="card-head">
        <h2>Расходы по категориям</h2>
        <span class="card-hint" id="dash-pie-hint">месяц</span>
    </div>
    <div class="chart-box" id="dash-pie-box">
        <canvas id="dash-pie" aria-label="Расходы по категориям"></canvas>
    </div>
    <div class="pie-legend" id="dash-pie-legend"></div>
</section>

<!-- Динамика: доходы и расходы по месяцам (выбор периода) -->
<section class="card chart-card reveal" style="--d:4">
    <div class="card-head">
        <h2>Динамика</h2>
        <div class="seg-inhead" id="dash-span" role="tablist" aria-label="Период динамики">
            <button class="seg-btn active" type="button" data-span="6">6 мес</button>
            <button class="seg-btn" type="button" data-span="12">Год</button>
            <button class="seg-btn" type="button" data-span="all">Всё</button>
        </div>
    </div>
    <div class="legend-inline" style="margin:0 0 10px 2px">
        <span><span class="dot" style="--c:var(--accent)"></span>Доходы</span>
        <span><span class="dot" style="--c:var(--warn)"></span>Расходы</span>
    </div>
    <div class="chart-box chart-box-sm">
        <canvas id="dash-bars" aria-label="Доходы и расходы по месяцам"></canvas>
    </div>
</section>
