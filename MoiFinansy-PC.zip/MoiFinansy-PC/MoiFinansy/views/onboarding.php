<?php
// ============================================================
// views/onboarding.php — мастер первого входа нового профиля
// ------------------------------------------------------------
// Показывается один раз после регистрации: программа знакомится
// с текущим финансовым положением пользователя.
//   шаг 1 — сколько сейчас свободных средств;
//   шаг 2 — какие есть накопления (цели и суммы в них);
//   шаг 3 — проверка введённого и сохранение.
// Пошаговое управление выполняет JS (assets/js/app.js).
// ============================================================
?>

<div class="onb-wrap">

    <!-- Круглый декор — в тон экрану входа -->
    <div class="auth-decor" aria-hidden="true">
        <span class="c1"></span>
        <span class="c2"></span>
        <span class="c3"></span>
        <span class="c4"></span>
        <span class="c5"></span>
    </div>

    <!-- Кнопка темы над карточкой -->
    <button class="topbar-btn auth-theme" id="theme-toggle" type="button"
            title="Сменить тему" aria-label="Сменить тему">
        <i class="fa-solid fa-sun" aria-hidden="true"></i>
    </button>

    <div class="card onb-card">

        <!-- Прогресс мастера -->
        <div class="onb-progress" aria-hidden="true">
            <span class="onb-dot active" data-dot="1"></span>
            <span class="onb-dot" data-dot="2"></span>
            <span class="onb-dot" data-dot="3"></span>
        </div>

        <div class="auth-brand">
            <div class="auth-logo"><i class="fa-solid fa-hand-holding-dollar" aria-hidden="true"></i></div>
            <h1>Добро пожаловать, <?= htmlspecialchars(mb_substr($userName, 0, 40)) ?>!</h1>
            <p>Давайте зафиксируем ваше текущее финансовое положение</p>
        </div>

        <!-- ---------- Шаг 1: свободные средства ---------- -->
        <section class="onb-step" data-step="1">
            <h2 class="onb-title">Сколько у вас сейчас свободных средств?</h2>
            <p class="onb-hint">
                Это деньги на руках и на счетах, которые не отложены в
                накопления. Если средств нет — оставьте ноль.
            </p>
            <label class="field">
                <span class="field-label">Свободные средства</span>
                <span class="input-affix onb-amount">
                    <input type="text" id="onb-free" inputmode="decimal"
                           placeholder="0" autocomplete="off">
                    <span class="affix">₽</span>
                </span>
            </label>
        </section>

        <!-- ---------- Шаг 2: существующие накопления ---------- -->
        <section class="onb-step" data-step="2" hidden>
            <h2 class="onb-title">Какие у вас есть накопления?</h2>
            <p class="onb-hint">
                Добавьте цели и укажите, сколько в них уже отложено.
                Целевую сумму можно не заполнять. Этот шаг можно пропустить.
            </p>

            <div id="onb-goals"></div>

            <button class="btn btn-sm onb-add" id="onb-add-goal" type="button">
                <i class="fa-solid fa-plus" aria-hidden="true"></i>
                Добавить накопление
            </button>
        </section>

        <!-- ---------- Шаг 3: подтверждение ---------- -->
        <section class="onb-step" data-step="3" hidden>
            <h2 class="onb-title">Всё верно?</h2>
            <p class="onb-hint">
                Так будет выглядеть стартовая картина. Всё остальное вы
                сможете изменить в любой момент.
            </p>
            <div class="onb-summary" id="onb-summary"></div>
        </section>

        <p class="form-error" id="onb-error" hidden></p>

        <!-- Навигация мастера -->
        <div class="onb-nav">
            <button class="btn" type="button" id="onb-back">
                <i class="fa-solid fa-arrow-left" aria-hidden="true"></i>
                Назад
            </button>
            <button class="btn btn-primary" type="button" id="onb-next">
                Далее
                <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
            </button>
        </div>
    </div>
</div>
