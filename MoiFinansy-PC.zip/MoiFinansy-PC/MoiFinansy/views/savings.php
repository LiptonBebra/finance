<?php
// ============================================================
// views/savings.php — накопления: цели с прогрессом,
// пополнение/снятие, история операций. Данные — savings.list.
// ------------------------------------------------------------
// Пополнение цели уменьшает свободный баланс, снятие —
// возвращает деньги. Проверки остатков делает сервер.
// ============================================================
?>

<section class="page-head reveal" style="--d:0">
    <div>
        <h1>Накопления</h1>
        <p class="page-sub">Свободно для откладывания: <b class="num" id="sav-free">—</b></p>
    </div>
</section>

<section class="reveal" style="--d:1">
    <div id="goals-list">
        <div class="card"><span class="skeleton skeleton-text"></span></div>
    </div>

    <button class="btn btn-primary btn-block" id="btn-add-goal" type="button">
        <i class="fa-solid fa-plus" aria-hidden="true"></i>
        Новая цель
    </button>
</section>
