<?php
// ============================================================
// views/stats.php — статистика: период (неделя/месяц/год/
// всё/свой диапазон), итоги, топ-5 категорий, круговая
// диаграмма и динамика трат. Пересчёт — fetch без перезагрузки.
// ============================================================
?>

<section class="page-head reveal" style="--d:0">
    <div>
        <h1>Статистика</h1>
        <p class="page-sub" id="st-period-label">Текущий месяц</p>
    </div>
</section>

<!-- Переключатель периода -->
<section class="reveal" style="--d:1">
    <div class="seg" id="st-seg">
        <button class="seg-btn" type="button" data-period="week">Неделя</button>
        <button class="seg-btn active" type="button" data-period="month">Месяц</button>
        <button class="seg-btn" type="button" data-period="year">Год</button>
        <button class="seg-btn" type="button" data-period="all">Всё</button>
        <button class="seg-btn" type="button" data-period="custom">Свой</button>
    </div>

    <!-- Свой диапазон дат -->
    <div class="range-picker" id="st-range" hidden>
        <input class="field-input" type="date" id="st-from" aria-label="Дата начала">
        <span class="range-sep">—</span>
        <input class="field-input" type="date" id="st-to" aria-label="Дата конца">
        <button class="btn btn-sm" id="st-apply" type="button">Ок</button>
    </div>
</section>

<!-- Итоги периода -->
<section class="stats-grid reveal" style="--d:2">
    <div class="card stat-card">
        <span class="stat-label">Доходы</span>
        <span class="stat-value pos num" id="st-income">—</span>
    </div>
    <div class="card stat-card">
        <span class="stat-label">Расходы</span>
        <span class="stat-value neg num" id="st-expense">—</span>
    </div>
    <div class="card stat-card">
        <span class="stat-label">Сальдо</span>
        <span class="stat-value num" id="st-net">—</span>
    </div>
    <div class="card stat-card">
        <span class="stat-label">В среднем в день</span>
        <span class="stat-value num" id="st-avg">—</span>
    </div>
</section>

<!-- Топ-5 категорий расходов -->
<section class="card chart-card reveal" style="--d:3">
    <div class="card-head">
        <h2>Топ-5 категорий расходов</h2>
    </div>
    <ul class="top-list" id="st-top">
        <span class="skeleton skeleton-text"></span>
    </ul>
</section>

<!-- Динамика трат -->
<section class="card chart-card reveal" style="--d:4">
    <div class="card-head">
        <h2>Динамика трат</h2>
        <div class="seg-inhead" id="st-gran" role="tablist" aria-label="Шаг динамики">
            <button class="seg-btn active" type="button" data-gran="day">Дни</button>
            <button class="seg-btn" type="button" data-gran="week">Недели</button>
            <button class="seg-btn" type="button" data-gran="month">Месяцы</button>
        </div>
    </div>
    <div class="chart-box">
        <canvas id="st-chart" aria-label="Динамика трат"></canvas>
    </div>
</section>

<!-- Распределение расходов -->
<section class="card chart-card reveal" style="--d:5">
    <div class="card-head">
        <h2>Структура расходов</h2>
    </div>
    <div class="chart-box chart-box-sm">
        <canvas id="st-pie" aria-label="Структура расходов"></canvas>
    </div>
    <div class="pie-legend" id="st-pie-legend"></div>
</section>
